<?php
$admin_name = $_SESSION['admin_name'];
$admin_role = admin_role($_SESSION['admin_role']);
?>
<header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>FP</b>E</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>FPE</b> SAS</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">

                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <span class="hidden-xs"><i class="fa fa-user"></i> <?php echo $admin_name; ?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <p><?php echo $admin_name ?> - <?php echo $admin_role; ?></p>
                        </li>
                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="password.php" class="btn btn-default btn-flat">Update Password</a>
                            </div>
                            <div class="pull-right">
                                <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                            </div>
                        </li>
                    </ul>
                </li>
                <!-- Control Sidebar Toggle Button -->
            </ul>
        </div>
    </nav>
</header>

<!-- =============================================== -->
<!-- =============================================== -->

<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">

        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="treeview">
                <a href="index.php">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>

            <li>
                <a href="import-data.php">
                    <i class="fa fa-download"></i> Import Data
                </a>
            </li>
            <li class="treeview">
                <a href="semester_summary.php">
                    <i class="fa fa-file"></i> Staff Semester Summary
                </a>
            </li>


            <li>
                <a href="view_schedule.php">
                    <i class="fa fa-eye-slash"></i> Print Attendance Sheet
                </a>
            </li>

            <li>
                <a href="view_cbt_schedule.php">
                    <i class="fa fa-eye-slash"></i> CBT Attendance Sheet
                </a>
            </li>

            <li>
                <a href="daily_schedule.php">
                    <i class="fa fa-print"></i> Print Daily Schedule
                </a>
            </li>

            <li>
                <a href="semester_schedule.php">
                    <i class="fa fa-print"></i> Print Semester Summary
                </a>
            </li>

            <li><a href="logout.php"><i class="fa fa-sign-out text-red"></i> <span>Logout</span></a></li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>