<?php
  require_once '../config/config.php';
  if(!admin())
  {
    header("location:login.php");
    exit();
  }
  $page_title = "Referral";
  $title = $page_title;
  include_once 'head.php';
  include_once 'menu.php';
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $page_title; ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
        <li class="active"><?php echo $page_title; ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_POST["create"])){
          $acid = $_POST["activation"];
          $code = rand(9,9999);
          $code2 = rand(9,999);
          $code = $code."-".$code2;
          $createCode = "INSERT into cashad_hub_activation (userid,activation) values ('$acid','$code')";
          $createCodeRes = $conn->query($createCode)or
          die(mysqli_error($conn));

          if($createCodeRes === TRUE){
            set_flash("Success","success");
          }else{
            set_flash("Not Successfull","danger");
          }
        }

      ?>
      <!-- Default box -->
      <span><?php echo flash(); ?></span>
      <div class="box box-info">
        <div class="box-header with-border">
          <h3 class="box-title"><?php echo $page_title; ?></h3>
        </div>
        <div class="box-body">
            <?php flash(); ?>
          <?php
            if(isset($_GET['act'])){
                switch ($_GET['act']) {
                    case 'del':
                        include_once 'inc/delete_activation.php'; //show delete page
                        break;

                    case 'view':
                        include_once 'inc/view_activation.php'; //view member info
                        break;
                        
                    default:
                        # code...
                        break;
                }
            }else{
                include_once 'inc/all_referrals.php';
            }
          ?>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          &nbsp;
        </div>
        <!-- /.box-footer-->
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php
  include_once 'foot.php';
?>