<h3 class="page-header">Edit Member Info</h3>
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$id = $_GET["id"];
		$sql = "SELECT * FROM cashad_hub_users WHERE user_id = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();
		//$rs = $sql->fetch(PDO::FETCH_ASSOC);
		//$sql->closeCursor();
		
		$name = explode(" ", $rs['name']);
		$surname = $name[0];
		$firstname = $name[1];
		$othernames = $name[2];


		?>

		<form action="" method="post" role="form">	
			<div class="form-group row">
				<div class="col-sm-4">
					<label>Surname</label>
					<input type="text" name="fname" required="" placeholder="First Name" class="form-control" value="<?php echo $surname; ?>">
				</div>
				<div class="col-sm-4">
					<label>First Name</label>
					<input type="text" name="lname" required="" placeholder="Last Name" class="form-control" value="<?php echo $firstname; ?>">
				</div>
				<div class="col-sm-4">
					<label>Other Names</label>
					<input type="text" name="lname" required="" placeholder="Last Name" class="form-control" value="<?php echo $othernames; ?>">
				</div>
			</div>

			<div class="form-group">
				<label>Phone Number</label>
				<input type="text" name="phone" required="" class="form-control" placeholder="Phone Number" value="<?php echo $rs['phone']; ?>">
			</div>

			<div class="form-group">
				<label>Email Address</label>
				<input type="email" name="email" required="" class="form-control" placeholder="Email Address" value="<?php echo $rs['email']; ?>">
			</div>							

			<div class="form-group row">
				<div class="col-sm-6">
					<label>State</label>
					<select name="state" required="" class="form-control">
						<option><?php echo $rs['state']; ?></option>				
					</select>
				</div>

				<div class="col-sm-6">
					<label>LGA</label>
					<select name="lga" required="" class="form-control" id="lga">
						<option><?php echo $rs['lga']; ?></option>
					</select>
				</div>
			</div>

			<div class="form-group">
				<label>Contact Address</label>
				<textarea class="form-control" readonly="" required="" placeholder="Contact Address" name="address"><?php echo $rs['address']; ?></textarea>
			</div>							

			<div class="form-group">
				<input type="submit" name="ok-update" class="btn btn-success" value="Update">								
			</div>							
		</form>

		<?php
	}
?>