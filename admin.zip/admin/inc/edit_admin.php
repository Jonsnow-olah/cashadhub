<h3 class="page-header">Edit Admin</h3>
<table class="table table-bordered" id="tables">
	<thead>
		<tr>
			<th>Sn</th>
			<th>Username</th>
			<th>Name</th>
			<th>Email</th>
			<th>Role</th>
			<th>Edit</th>
		</tr>
	</thead>
	<tbody>
		<?php
			$sql = "SELECT id,name,username,role,email FROM cashad_hub_admin ORDER BY id DESC";
			$results = $conn->query($sql)or
			die(mysqli_error($conn));
			$sn = 0;
			if($results->num_rows > 0){
				while ($rs = $results->fetch_assoc()) {
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['name'];?></td>
					<td><?php echo $rs['username'];?></td>
					<td><?php echo $rs['email'];?></td>
					<td><?php echo $rs['role'];?></td>
					<td>
						<a href='admin.php?act=edit_admin&id=<?php echo $rs['id'];?>' class='btn btn-sm btn-info' title='Edit' data-toggle='tooltip'><i class='glyphicon glyphicon-pencil'></i></a>
					</td>
				</tr>
				<?php
			}
		}
			//$sql->closeCursor();
		?>
	</tbody>
</table>