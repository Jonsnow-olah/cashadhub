<h3 class="page-header">All Referral</h3>
<div class="table-responsive">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>Referral Id</th>
                <th>Invited Member Id</th>
                <th>Status</th>
                <th>Date</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_ref ORDER BY id DESC";
			$result = $conn->query($user)or
			die(mysqli_error($conn));
			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc()){
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['refuserid']; ?></td>
                    <td><?php echo $rs['inviteduserid'];?></td>
                    <td>
                    	<a <?php if($rs["status"] == "Activated"){echo "class='btn btn-info'";}elseif($rs["status"] == "Not Activated"){echo "class='btn btn-warning'";} ?>><?php echo $rs["status"]; ?></a>
                	</td>
                    <td><?php echo $rs["date"]; ?></td>
					<td><form action="" method="post" class='delete-member'>
							<button type="submit" name='ok-delete' value='<?php echo $rs['id'];?>' class='btn btn-sm btn-danger' title='Delete' data-toggle='tooltip'>
								<i class='glyphicon glyphicon-trash'></i>
							</button>
						</form></a>
					</td>
				</tr>
				<?php
			}
		}
		$conn->close();
		?>
	</tbody>
	</table>
</div>