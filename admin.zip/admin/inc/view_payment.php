<h3 class="page-header">View Payment</h3>
<div class="table-responsive">
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$id = $_GET["id"];
	}
?>
<?php
	
		$sql = "SELECT * FROM cashad_hub_payment WHERE id = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();

		?>
		<table class="table table-bordered">
			<tr>
				<th>Id</th>
				<td><?php echo $rs['id']; ?></td>
				<td rowspan="7"><img style="width: 200px; height: 250px;" src="../payment/<?php echo $rs['file']; ?>"></td>
			</tr>
			<tr>
				<th>Payer</th>
				<td><?php echo $rs['payer'];?></td>
			</tr>
			<tr>
				<th>Beneficiary</th>
				<td><?php echo $rs['beneficiary']; ?></td>
			</tr>
			<tr>
				<th>Amount</th>
				<td>&#8358;<?php echo number_format($rs['amount']); ?></td>
			</tr>
			<tr>
				<th>Paid</th>
				<td><?php if($rs["paid"] == 1){echo "Yes";}else{echo "No";} ?></td>
			</tr>
			<tr>
				<th>Received</th>
				<td><?php if($rs["received"] == 1){echo "Yes";}else{echo "No";} ?></td>
			</tr>
			<tr>
				<th>Action</th>
				<td><?php echo $rs["action"]; ?></td>
			</tr>
			<tr>
				<th>Received</th>
				<td><?php echo $rs["date_upload"]; ?></td>
			</tr>
		</table>
		
		
		<?php

	$conn->close();
?>
</div>