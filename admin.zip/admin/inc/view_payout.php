<h3 class="page-header">View Payout</h3>
<h4 class="page-header">Payout Request Info</h4>
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$id = $_GET["id"];
	}
	if(isset($_POST["merge"])){
		$merger = $_POST["ids"];
	
		$countRec = "SELECT count from cashad_hub_merge where userid = '$id' ";
		$countRecRes = $conn->query($countRec)or
		die(mysqli_error());

		$add = strtotime("+5 Hours");
		$mergeDate = date("F d, Y H:i:s",$add);
		$countRecRs = $countRecRes->fetch_assoc();
		$totalCout = $countRecRs["count"] + 1;

		$updateMerge = "UPDATE cashad_hub_merge set status = 'Merge', merge = '$id', count = '1', date_merge = '$mergeDate' where userid = '$merger' ";
		$updateMergeRes = $conn->query($updateMerge)or
		die(mysqli_error($conn));

		$updateCount = "UPDATE cashad_hub_merge set status = 'Merge', merge = 'Yes', count = '$totalCout', date_merge = '$mergeDate' where userid = '$id' ";
		$updateCountRes = $conn->query($updateCount)or
		die(mysqli_error($conn));

		if($updateMergeRes === TRUE and $updateCountRes === TRUE){
			set_flash("Merge successfully","success");
			unset($_GET["ids"]);
		}else{
			set_flash("There was error in mergin","danger");
		}
	}
		$sql = "SELECT * FROM cashad_hub_merge WHERE userid = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();
		?>
		<form action="" method="post" role="form">
			<div class="form-group row">
				<div class="col-sm-4">
					<label>User Id</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["userid"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Amount</label>
					<input type="text" name="lname" readonly="" class="form-control" value="<?php echo $rs["amount"]; ?>">
				</div>
			</div>

			<div class="form-group row">
				<div class="col-sm-4">
					<label>Type</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["type"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Status</label>
					<input type="text" name="lname" readonly="" class="form-control" value="<?php echo $rs["status"]; ?>">
				</div>
			</div>						

			<div class="form-group row">
				<div class="col-sm-4">
					<label>Merge</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["count"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Date</label>
					<input type="text" name="lname" readonly="" class="form-control" value="<?php echo $rs["date_time"]; ?>">
				</div>
			</div>
			<div class="form-group row">
				<div class="col-sm-8">
					<label>Level</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["level"]; ?>">
				</div>
			</div>							
		</form>
		