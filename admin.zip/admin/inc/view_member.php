<h3 class="page-header">View Member Profile</h3>
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$id = $_GET["id"];
		$sql = "SELECT * FROM cashad_hub_users WHERE userid = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();

		$userid = $rs["userid"];
		$myId = $rs["id"];
		$level = "SELECT cashad_hub_users.level, cashad_hub_levels.level as level from cashad_hub_users inner join cashad_hub_levels on cashad_hub_users.level = cashad_hub_levels.id where cashad_hub_users.userid = '$userid' ";

		$levelres = $conn->query($level)or
		die(mysqli_error($conn));

		$levelrs = $levelres->fetch_assoc();
		//$sql->closeCursor();

		//var_dump($rs);
		//exit();

		?>
		<table class="table table-bordered">
			<tr>
				<th>User Id</th>
				<td><?php echo $rs['userid']; ?></td>
				<td rowspan="3"><img src="<?php echo '../passports/'.$rs['passport']; ?>" style="width: 100px; height: 100px;" /></td>
			</tr>
			<tr>
				<th>Name</th>
				<td><?php echo $rs['name']; ?></td>
			</tr>
			<tr>
				<th>Email Address</th>
				<td><?php echo $rs['email']; ?></td>
			</tr>
			<tr>
				<th>Phone Number</th>
				<td><?php echo $rs['phone']; ?></td>
			</tr>
			<tr>
				<th>Level</th>
				<td><?php echo $levelrs['level']; ?></td>
			</tr>
			<tr>
				<th>Address</th>
				<td><?php echo $rs['username']; ?></td>
			</tr>
			<tr>
				<th>Account Status</th>
				<td><?php echo($rs['status']); ?></td>
			</tr>

			<?php //$sql->closeCursor(); ?>
		</table>
		<?php
		if (isset($_POST["ok-status"])) {
			$status = $_POST["status"];
			$sql = "UPDATE cashad_hub_users set status = '$status' where userid = '$userid' ";
			$result = $conn->query($sql)or
			die(mysqli_error($conn));

			if($result === TRUE){

				set_flash("Status updated successfully","success");
			}

		}
		?>
		<form action='' method='post'>
			<?php flash() ?>
			<div class='form-group'>
				<label>Change Account Status</label>
				<select name='status' class='form-control' required="required">
					<option selected=""></option>
					<option value='Active'>Active</option>
					<option value='Suspended'>Suspended</option>
					<option value='Banned'>Banned</option>
				</select>
			</div>

			<div class='form-group'>
				<input type='submit' name='ok-status' value='Update' class='btn btn-success'>
			</div>
		</form>
		<h3 class="page-header">Bank Account Details</h3>
		<?php
		$bank = "SELECT * from cashad_hub_user_bank where userid = '$userid' ";
		$result = $conn->query($bank)or
		die(mysqli_error($conn));

		$bk = $result->fetch_assoc();
		?>
		<table class="table table-bordered">
			<tr>
				<td>User Id</td>
				<td><?php echo $bk["userid"]; ?></td>
			</tr>
			<tr>
				<td>Account Name</td>
				<td><?php echo $bk["account_name"]; ?></td>
			</tr>
			<tr>
				<td>Account Number</td>
				<td><?php echo $bk["account_num"]; ?></td>
			</tr>
			<tr>
				<td>Bank Name</td>
				<td><?php echo $bk["bank_name"]; ?></td>
			</tr>
		</table>
		<h3 class="page-header">Legder</h3>
		<table class="table table-bordered" id="">
			<thead>
				<tr>
					<th>User Id</th>
					<th>Withdraw</th>
					<th>Savings</th>
					<th>Bonus</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$selectledger = "SELECT * from cashad_hub_ledger where userid = '$userid' ";
				$result = $conn->query($selectledger)or
				die(mysqli_error($conn));

				$print = $result->fetch_assoc();
				?>
				<tr>
					<td><?php echo $print["userid"]; ?></td>
					<td>&#8358; <?php echo number_format($print["withdraw"]); ?></td>
					<td>&#8358; <?php echo number_format($print["savings"]); ?></td>
					<td>&#8358; <?php echo number_format($print["bonus"]); ?></td>
				</tr>
			</tbody>
		</table>
		<h3 class='page-header'>Wallet/Payment History</h3>
		<table class="table table-bordered" id='tables'>
			<thead>
				<tr>
					<th>ID</th>
					<th>Sender Id</th>
					<th>Receiver Id</th>
					<th>Initial Payment</th>
					<th>Release Date</th>
				</tr>
			</thead>
			<tbody>
				<?php
				
					$payment = "SELECT * FROM cashad_hub_payment WHERE payer = '$myId' ";
					$result = $conn->query($payment)or
					die(mysqli_error($conn));
					$sn = 0;
					if($result->num_rows > 0){
						while($rsss = $result->fetch_assoc()){
							$date = strtotime($rsss["date_upload"]);
							?>
							<tr>
								<td><?php echo ++$sn?></td>
								<td><?php echo $rsss['sender_id'];?></td>
								<td><?php echo $rsss['receiver_id'];?></td>
								<td>&#8358;<?php echo number_format($rsss['amount']);?></td>
								<td><?php echo date("F d, Y, h-i a",$date);?></td>
								<td>
									<form action='' method='post' class='btn-delete-wallet'>
										<button name='ok-del-wallet' value='<?php echo $rs['id'];?>' class='btn btn-sm btn-danger' type='submit' title='Delete'>
											<i class='fa fa-trash-o'></i>
										</button>
									</form>
								</td>
							</tr>
							<?php
						}
					}
					//$w->closeCursor();
					//*/
				?>
			</tbody>
		</table>
			
		<?php

	}
?>