<h3 class="page-header">Edit Admin</h3>
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$sql = "SELECT id,name,username,role,email FROM cashad_hub_admin ORDER BY id DESC";
		$results = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $results->fetch_assoc();
		//$sql->closeCursor();

		?>
			<form action="" method="post" role='form'>
				<div class="form-group">
					<label>Username</label>
					<input type="text" name="username" required="" class="form-control" value="<?php echo $rs['username']; ?>">
				</div>

				<div class="form-group">
					<label>Name</label>
					<input type="text" name="name" required="" class="form-control" value="<?php echo $rs['name']; ?>">
				</div>

				<div class="form-group">
					<label>Email</label>
					<input type="email" name="email" required="" class="form-control" value="<?php echo $rs['email']; ?>">
				</div>	

				<div class="form-group">
					<label>Role</label>
					<select class="form-control" name="role" required="">
						<option value="0" <?php if($rs['role'] == "mode"){echo 'selected';} ?>>Moderator</option>
						<option value="1" <?php if($rs['role'] == "admin"){echo 'selected';} ?>>Admin</option>
					</select>
				</div>
				<div class="form-group">
					<label>New Password</label>
					<input type="password" name="password" required="" class="form-control">
				</div>
				<div class="form-group">
					<button type="submit" name="edit" class="btn btn-sm btn-success"><i class="fa fa-user-plus"></i> Update</button>
				</div>
			</form>

		<?php
	}
?>