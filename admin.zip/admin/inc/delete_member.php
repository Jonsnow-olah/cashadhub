<h3 class="page-header">Delete Member</h3>
<div class="responsive-table">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>User Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Phone</th>
				<th>Status</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_users ORDER BY id DESC";

			$result = $conn->query($user)or
			die(mysqli_error($conn));

			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc())
			{
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['user_id']; ?></td>
					<td><?php echo $rs['name'];?></td>
					<td><?php echo $rs['email'];?></td>
					<td><?php echo $rs['phone'];?></td>
					<td><?php echo $rs['status'];?></td>
					<td>
						<form action="" method="post" class='delete-member'>
							<button type="submit" name='ok-delete' value='<?php echo $rs['id'];?>' class='btn btn-sm btn-danger' title='Delete' data-toggle='tooltip'>
								<i class='glyphicon glyphicon-trash'></i>
							</button>
						</form>
					</td>
				</tr>
				<?php
			}
		}

			$conn->close();
		?>
	</tbody>
	</table>
</div>