<h3 class="page-header">All Referral Bonus Withdrawal</h3>
<?php
if(isset($_GET["pay"])){
	$id = mysqli_real_escape_string($conn,$_GET["id"]);
	$update = "UPDATE cashad_hub_bonus set paid = 'Paid' where id = '$id' ";
	$updateRes = $conn->query($update)or
	die(mysqli_error($conn));
	if($updateRes === TRUE){
	?>
	<script>
        var text = confirm("Payment updated successfully");
        if(text === true){
         	window.location.href="bonus";
    	}
    </script>
    <?php
	}else{
		set_flash("There was error in updating payment","danger");
	}
}
?>
<span><?php echo flash(); ?></span>
<div class="table-responsive">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>User Id</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Action</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_bonus ORDER BY id DESC";
			$result = $conn->query($user)or
			die(mysqli_error($conn));
			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc()){
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['userid']; ?></td>
                    <td>&#8358;<?php echo number_format($rs['amount']);?></td>
                    <td><span <?php if($rs["paid"] == "Pending"){echo "class='btn btn-warning btn-sm'";}elseif($rs["paid"] == "Paid"){echo "class='btn btn-success btn-sm'";} ?>><?php echo $rs["paid"]; ?></span></td>
                    <td>
                    	<?php
                    	if($rs["paid"] == "Pending"){
                    ?>
                    <a class="btn btn-success btn-sm" href="bonus.php?pay=yes&id=<?php echo($rs["id"])?>">Pay <i class="fa fa-check"></i></a>
                    <?php
                    	}elseif($rs["paid"] == "Paid"){
                    ?>
                    <a class="btn btn-success btn-sm disabled" href="javascript:void();">Pay <i class="fa fa-check"></i></a>
                    <?php
                    }
                    ?>
                    </td>
					<td><form action="" method="post" class='delete-member'>
							<button type="submit" name='ok-delete' value='<?php echo $rs['id'];?>' class='btn btn-sm btn-danger' title='Delete' data-toggle='tooltip'>
								<i class='glyphicon glyphicon-trash'></i>
							</button>
						</form></a>
					</td>
				</tr>
				<?php
			}
		}
		$conn->close();
		?>
	</tbody>
	</table>
</div>