<h3 class="page-header">All Payment</h3>
<div class="table-responsive">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>Payer</th>
				<th>Beneficiary</th>
                <th>Amount</th>
                <th>Proof</th>
                <th>Date</th>
                <th>Action</th>
				<th>View</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_payment ORDER BY id DESC";
			$result = $conn->query($user)or
			die(mysqli_error($conn));
			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc()){
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['payer']; ?></td>
                    <td><?php echo $rs['beneficiary'];?></td>
                    <td>&#8358;<?php echo number_format($rs['amount']);?></td>
                    <td><img style="width: 30px; height: 25px;" src="../payment/<?php echo $rs["file"];?>"></td>
                    <td><?php echo $rs["date_upload"]; ?></td>
                    <td><?php echo $rs["action"]; ?></td>
					<td><a class="btn btn-sm btn-primary" href="payment.php?act=view&id=<?php echo($rs['id']); ?>">View <i class="fa fa-eye"></i></a></td>
					<td><a class="btn btn-sm btn-danger" href="receive.php?act=del">Delete <i class="glyphicon glyphicon-trash"></i></a></td>
				</tr>
				<?php
			}
		}
		$conn->close();
		?>
	</tbody>
	</table>
</div>