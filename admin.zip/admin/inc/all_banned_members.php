<h3 class="page-header">Banned Members</h3>
<div class="table-responsive">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>User Id</th>
				<th>Name</th>
                <th>Level</th>
                <th>Phone</th>
                <th>Username</th>
				<th>Status</th>
				<th>View</th>
				<td>Delete</td>
				<th>Edit</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_users WHERE status = 'Banned' ORDER BY id ASC";
			$result = $conn->query($user)or
			die(mysqli_error($conn));
			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc()){
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['user_id']; ?></td>
					<td><?php echo $rs['name'];?></td>
                    <td><?php echo $rs['level'];?></td>
                    <td><?php echo $rs['phone'];?></td>
                    <td><?php echo $rs['username'];?></td>
					<td><?php echo $rs['status'];?></td>
					<td><a class="btn btn-sm btn-primary" href="member.php?act=view&id=<?php echo($rs['user_id']) ?>">View <i class="fa fa-eye"></i></a></td>
					<td><a class="btn btn-sm btn-danger" href="member.php?act=del">Delete <i class="glyphicon glyphicon-trash"></i></a></td>
					<td><a class="btn btn-sm btn-info" href="member.php?act=edit">Edit <i class="glyphicon glyphicon-edit"></i></a></td>
				</tr>
				<?php
			}
		}

			$conn->close();
		?>
	</tbody>
	</table>
</div>