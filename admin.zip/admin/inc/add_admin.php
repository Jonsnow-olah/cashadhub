<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$username = htmlspecialchars($_POST["username"]);
	$password = htmlspecialchars(sha1($_POST["password"]));
	$name = htmlspecialchars($_POST["name"]);
	$email = htmlspecialchars($_POST["email"]);
	$role = htmlspecialchars($_POST["role"]);

	$sql = "INSERT into cashad_hub_admin (name,username,email,password,role) values ('$name','$username','$email','$password','$role')";
	$results = $conn->query($sql)or
	die(mysqli_error($conn));

	if($results === TRUE){
		set_flash("New admin added successfully","success");
	}else{
		set_flash("There was error in adding new admin","danger");
	}

}
?>
<h3 class="page-header">Add New Admin</h3>
<?php flash() ?>
<form action="" method="post" role='form'>
	<div class="form-group">
		<label>Username</label>
		<input type="text" name="username" required="" class="form-control">
	</div>
	
	<div class="form-group">
		<label>Password</label>
		<input type="password" name="password" required="" class="form-control">
	</div>
	<div class="form-group">
		<label>Name</label>
		<input type="text" name="name" required="" class="form-control">
	</div>

	<div class="form-group">
		<label>Email</label>
		<input type="email" name="email" required="" class="form-control">
	</div>

	

	<div class="form-group">
		<label>Role</label>
		<select class="form-control" name="role" required="">
			<option></option>
			<option value="mode">Moderator</option>
			<option value="admin">Admin</option>
		</select>
	</div>

	<div class="form-group">
		<button type="submit" name="ok-add" class="btn btn-sm btn-success"><i class="fa fa-fw fa-plus"></i> Add</button>
	</div>
</form>