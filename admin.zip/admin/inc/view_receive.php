<h3 class="page-header">View Receive</h3>
<h4 class="page-header">Receive Request Info</h4>
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$id = $_GET["id"];
	}
	if(isset($_POST["merge"])){
		$merger = $_POST["ids"];
		//Count number merge to beneficiary
		$countRec = "SELECT count from cashad_hub_merge where userid = '$id' ";
		$countRecRes = $conn->query($countRec)or
		die(mysqli_error($conn));
		
		//Select Merger Amount
		$mergeAmount = "SELECT amount from cashad_hub_merge where userid = '$merger' ";
		$mergeAmountRes = $conn->query($mergeAmount)or
		die(myasli_error($conn));
		$mergeAmountRs = $mergeAmountRes->fetch_assoc();
		$amountToMerge = $mergeAmountRs["amount"];


		//Select Beneficiary Amount
		$sql = "SELECT amount FROM cashad_hub_merge WHERE userid = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();
		$checkAmount = $rs["amount"];

		//Sum Amount to Received by Beneficiary
		$seBenTotSum = "SELECT sum(amount) as benTotSum from cashad_hub_merge where merge = '$id'";
		$seBenTotSumRes  = $conn->query($seBenTotSum)or
		die(mysqli_error($conn));
		$seBenTotSumRs = $seBenTotSumRes->fetch_assoc();
		$benTotSum = $seBenTotSumRs["benTotSum"];
		$sumOfAmount = $amountToMerge + $benTotSum;

		
		//Add 5 hours to counting
		$add = strtotime("+5 Hours");
		$mergeDate = date("F d, Y H:i:s",$add);
		$countRecRs = $countRecRes->fetch_assoc();
		$totalCout = $countRecRs["count"] + 1;


		if($sumOfAmount > $checkAmount){
			$diff = $checkAmount - $benTotSum;
			set_flash("The amount to receive will be more than amount to be receive, amount left is &#8358;$diff ","danger");
		}else{
				$updateMerge = "UPDATE cashad_hub_merge set status = 'Merge', merge = '$id', count = '1', date_merge = '$mergeDate' where userid = '$merger' ";
				$updateMergeRes = $conn->query($updateMerge)or
				die(mysqli_error($conn));

				$updateCount = "UPDATE cashad_hub_merge set status = 'Merge', merge = 'Yes', count = '$totalCout', date_merge = '$mergeDate' where userid = '$id' ";
				$updateCountRes = $conn->query($updateCount)or
				die(mysqli_error($conn));

				if($updateMergeRes === TRUE and $updateCountRes === TRUE){
					set_flash("Merge successfully","success");
					unset($_GET["ids"]);
				}else{
					set_flash("There was error in mergin","danger");
				}
			}
		}
	
		$sql = "SELECT * FROM cashad_hub_merge WHERE userid = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();
		$sumAmount = $rs["amount"];
		?>
		<?php echo flash();?>
		<form action="" method="post" role="form">
			<div class="form-group row">
				<div class="col-sm-4">
					<label>User Id</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["userid"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Amount</label>
					<input type="text" name="lname" readonly="" class="form-control" value="<?php echo $rs["amount"]; ?>">
				</div>
			</div>

			<div class="form-group row">
				<div class="col-sm-4">
					<label>Type</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["type"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Status</label>
					<input type="text" name="lname" readonly="" class="form-control" value="<?php echo $rs["status"]; ?>">
				</div>
			</div>						

			<div class="form-group row">
				<div class="col-sm-4">
					<label>Count</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["count"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Date</label>
					<input type="text" name="lname" readonly="" class="form-control" value="<?php echo $rs["date_time"]; ?>">
				</div>
			</div>
			<div class="form-group row">
				<div class="col-sm-4">
					<label>Level</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["level"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Current Amount Receive</label>
					<input type="text" name="lname" readonly="" class="form-control" value="<?php echo "&#8358;".number_format($rs["payment"]); ?>">
				</div>
			</div>							
		</form>
		<?php 
		$countMerge = "SELECT sum(amount) as totSum from cashad_hub_merge where merge = '$id' ";
		$countRes  = $conn->query($countMerge)or
		die(mysqli_error($conn));
		$countRs = $countRes->fetch_assoc();

		//Sum of amount already received
		$checkPayment = "SELECT payment from cashad_hub_merge where userid = '$id' and status = 'Merge' and merge = 'Yes' ";
		$checkPaymentRes = $conn->query($checkPayment)or
		die(mysqli_error($conn));
		$sumOfPaymentRs = $checkPaymentRes->fetch_assoc();
		$totSumOfReceived = $sumOfPaymentRs["payment"];
		$amReceived = $totSumOfReceived + $countRs["totSum"];
		$left = $sumAmount - $amReceived;
		?>
		<div class="alert alert-info">Total amount left to be added to the merge details above &#8358;<?php echo $left; ?></div>
		<div class="table-responsive">
		<?php
		if($countRs["totSum"] == $sumAmount || $amReceived == $sumAmount){
		?>
		<h3 class="page-header">This request alredy fill up with the require number of merging</h3>
		<table class="table table-bordered" id="tables">
			<thead>
				<tr>
					<th>Sn</th>
					<th>User Id</th>
	                <th>Amount</th>
	                <th>Type</th>
	                <th>Level</th>
	                <th>Status</th>
	                <th>Merge</th>
					<th>Action</th>
				</tr>
			</thead>
		</table>
		<?php
			}else{
		?>
		<h3 class="page-header">Available Members for merging</h3>
		<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>User Id</th>
                <th>Amount</th>
                <th>Type</th>
                <th>Level</th>
                <th>Status</th>
                <th>Merge</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$twoMembers = $rs["amount"]/2;
			$fourmembers = $rs["amount"]/4;
			$oneMember = $rs["amount"];
			$level = $rs["level"];
			$getMerge = "SELECT * from cashad_hub_merge where ((amount = '$oneMember' || amount = '$twoMembers' || amount = '$fourmembers' || level <= '$level') and type = 'Payout' and merge = 'nill') limit 20 ";
			$getRes = $conn->query($getMerge)or
			die(mysqli_error($conn));
			if($getRes->num_rows > 0){
				$sn = 0;
				while($geRs = $getRes->fetch_assoc()){
		?>
			<tr>
				<td><?php echo ++$sn;?></td>
				<td><?php echo $geRs['userid']; ?></td>
                <td><?php echo number_format($geRs['amount']);?></td>
                <td><?php echo $geRs['type'];?></td>
                <td><?php echo $geRs["level"];?></td>
                <td><?php echo $geRs['status'];?></td>
                <td><?php echo $geRs["merge"]; ?></td>
				<td>
					<form method="post">
						<input type="hidden" name="ids" value="<?php echo($geRs['userid']); ?>">
						<button type="submit" name="merge" class="btn btn-sm btn-primary">Merge <i class="fa fa-users"></i></button>
					</form>
				</td>
			</tr>
		<?php

				}
			}
		}
		?>
			</tbody>
		</table>
		</div>