<h3 class="page-header">Edit Member</h3>
<div class="responsive-table">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>Name</th>
				<th>Phone</th>
				<th>Location</th>
				<th>Edit</th>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_users ORDER BY id DESC";
			$result = $conn->query($user)or
			die(mysqli_error($conn));

			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc())
			{
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['name'];?></td>
					<td><?php echo $rs['phone'];?></td>
					<td><?php echo $rs['email'].", ".$rs['status'];?></td>
					<td>
						<a href='member.php?act=edit_member&id=<?php echo $rs['user_id'];?>' class='btn btn-sm btn-info' title='Edit' data-toggle='tooltip'><i class='glyphicon glyphicon-pencil'></i></a>
					</td>
				</tr>
				<?php
			}
		}

		$conn->close();
		?>
	</tbody>
	</table>
</div>