<h3 class="page-header">View Member Profile</h3>
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$id = $_GET["id"];
		$sql = "SELECT * FROM cashad_hub_advert_user WHERE userid = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();

		$userid = $rs["userid"];
		//$sql->closeCursor();

		//var_dump($rs);
		//exit();

		?>
		<table class="table table-bordered">
			<tr>
				<th>User Id</th>
				<td><?php echo $rs['userid']; ?></td>
			</tr>
			<tr>
				<th>Name</th>
				<td><?php echo $rs['name']; ?></td>
			</tr>
			<tr>
				<th>Email Address</th>
				<td><?php echo $rs['email']; ?></td>
			</tr>
			<tr>
				<th>Phone Number</th>
				<td><?php echo $rs['phone']; ?></td>
			</tr>
			<tr>
				<th>Username</th>
				<td><?php echo $rs['username']; ?></td>
			</tr>
			<tr>
				<th>Date Registered</th>
				<td><?php echo $rs['date_register'] ;?></td>
			</tr>
		</table>
		
		<h3 class="page-header">Comapany/Business Details</h3>
		<?php

		$bank = "SELECT * from cashad_hub_advert_company where userid = '$userid' ";
		$result = $conn->query($bank)or
		die(mysqli_error($conn));

		$bk = $result->fetch_assoc();
		?>
		<table class="table table-bordered">
			<tr>
				<td>User Id</td>
				<td><?php echo $bk["userid"]; ?></td>
			</tr>
			<tr>
				<td>Company Name</td>
				<td><?php echo $bk["company_name"]; ?></td>
			</tr>
			<tr>
				<td>Company Email</td>
				<td><?php echo $bk["company_email"]; ?></td>
			</tr>
			<tr>
				<td>Company Phone</td>
				<td><?php echo $bk["company_phone"]; ?></td>
			</tr>
			<tr>
				<td>Company Address</td>
				<td><?php echo $bk["company_address"]; ?></td>
			</tr>
			<tr>
				<td>Service Render</td>
				<td><?php echo $bk["service_rendered"]; ?></td>
			</tr>
			<tr>
				<td>Date Establish</td>
				<td><?php echo $bk["year_establish"]; ?></td>
			</tr>
		</table>
		<?php

	}
?>