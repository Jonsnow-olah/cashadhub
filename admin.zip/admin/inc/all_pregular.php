<h3 class="page-header">All Regular Payout Request</h3>
<div class="table-responsive">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>User Id</th>
                <th>Amount</th>
                <th>Type</th>
                <th>Status</th>
                <th>Merge</th>
				<th>View</th>
				<td>Delete</td>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_merge where type = 'payout' and amount = 1000 ORDER BY id ASC";
			$result = $conn->query($user)or
			die(mysqli_error($conn));
			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc()){
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['userid']; ?></td>
                    <td><?php echo number_format($rs['amount']);?></td>
                    <td><?php echo $rs['type'];?></td>
                    <td><?php echo $rs['status'];?></td>
                    <td><?php echo $rs["merge"]; ?></td>
					<td><a class="btn btn-sm btn-primary" href="payout.php?act=view&id=<?php echo($rs['userid']); ?>">View <i class="fa fa-eye"></i></a></td>
					<td><a class="btn btn-sm btn-danger" href="payout.php?act=del">Delete <i class="glyphicon glyphicon-trash"></i></a></td>
				</tr>
				<?php
			}
		}

			$conn->close();
		?>
	</tbody>
	</table>
</div>