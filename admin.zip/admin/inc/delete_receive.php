<h3 class="page-header">Delete Recceive Request</h3>
<div class="table-responsive">
	<table class="table table-bordered" id="tables">
		<thead>
			<tr>
				<th>Sn</th>
				<th>User Id</th>
                <th>Amount</th>
                <th>Type</th>
                <th>Status</th>
                <th>Merge</th>
				<td>Delete</td>
			</tr>
		</thead>
		<tbody>
		<?php
			$user = "SELECT * FROM cashad_hub_request where type = 'Receive' and opp = 0 ORDER BY id ASC";
			$result = $conn->query($user)or
			die(mysqli_error($conn));
			$sn = 0;
			if($result->num_rows > 0){
			while($rs = $result->fetch_assoc()){
				?>
				<tr>
					<td><?php echo ++$sn;?></td>
					<td><?php echo $rs['userid']; ?></td>
                    <td><?php echo number_format($rs['amount']);?></td>
                    <td><?php echo $rs['type'];?></td>
                    <td><?php echo $rs['status'];?></td>
                    <td><?php echo $rs["merge"]; ?></td>
					<td><form action="" method="post" class='delete-member'>
							<button type="submit" name='ok-delete' value='<?php echo $rs['userid'];?>' class='btn btn-sm btn-danger' title='Delete' data-toggle='tooltip'>
								<i class='glyphicon glyphicon-trash'></i>
							</button>
						</form></td>
				</tr>
				<?php
			}
		}
		$conn->close();
		?>
	</tbody>
	</table>
</div>