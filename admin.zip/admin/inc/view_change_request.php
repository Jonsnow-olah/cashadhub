<h3 class="page-header">Change Request</h3>
<h4 class="page-header">Change Request Info</h4>
<?php
	if(!isset($_GET['id'])){
		echo "<div class='alert alert-info'>Invalid Request!</div>";
	}else{
		$id = $_GET["id"];
	}

	if(isset($_POST['change'])){
		$amount = mysqli_real_escape_string($conn,$_POST["amount"]);
		$type = mysqli_real_escape_string($conn,$_POST["type"]);

		$changeRequest = "UPDATE cashad_hub_merge set amount = '$amount', type = '$type' where userid = '$id' and type = 'Payout' ";
		$changeRequestRes = $conn->query($changeRequest)or
		die(mysqli_error($conn));
		if($changeRequestRes === TRUE){
			set_flash("Request change successfully","success");
		}else{
			set_flash("There was error in updating request","danger");
		}

	}
		$sql = "SELECT * FROM cashad_hub_merge WHERE userid = '$id' ";
		$result = $conn->query($sql)or
		die(mysqli_error($conn));
		$rs = $result->fetch_assoc();
		?>
		<?php echo flash(); ?>
		<form method="post" role="" name="updating" action="">
			<div class="form-group row">
				<div class="col-sm-4">
					<label>User Id</label>
					<input type="text" name="fname" readonly="" class="form-control" value="<?php echo $rs["userid"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Amount</label>
					<select class="form-control" name="amount">
						<option><?php echo $rs["amount"]; ?></option>
						<option>1000</option>
						<option>2000</option>
						<option>3000</option>
						<!--
						<option>5000</option>
						<option>10000</option>
						<option>20000</option>
					-->
					</select>
				</div>
			</div>

			<div class="form-group row">
				<div class="col-sm-4">
					<label>Type</label>
					<select class="form-control" name="type">
						<option><?php echo $rs["type"]; ?></option>
						<option>Payout</option>
						<option>Receive</option>
					</select>
				</div>
				<div class="col-sm-4">
					<label>Status</label>
					<input class="form-control" type="text" disabled="" name="status" value="<?php echo $rs["status"]; ?>">
				</div>
			</div>						

			<div class="form-group row">
				<div class="col-sm-4">
					<label>Count</label>
					<input class="form-control" type="text" disabled="" name="count" value="<?php echo $rs["count"]; ?>">
				</div>
				<div class="col-sm-4">
					<label>Date</label>
					<input type="text" name="date" readonly="" class="form-control" value="<?php echo $rs["date_time"]; ?>">
				</div>
			</div>	
			<div class="form-group row">
				<div class="col-sm-8">
					<label>Merge</label>
					<input class="form-control" type="text" disabled="" name="merge" value="<?php echo $rs["merge"]; ?>">
				</div>
			</div>
			<div class="button-group">
				<button class="btn btn-success" type="submit" name="change" value="">Change Request <i class="fa fa-exchange"></i></button>
			</div>					
		</form>
		