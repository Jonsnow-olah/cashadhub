<?php
$admin_name = $_SESSION['admin_name'];
$admin_role = admin_role($_SESSION['admin_role']);
?>
<header class="main-header">
    <!-- Logo -->
    <a href="index.php" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>CAH</b></span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><b>CashAd</b> Hub</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
        <!-- Sidebar toggle button-->
        <a href="javascript:void();" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">

                <!-- User Account: style can be found in dropdown.less -->
                <li class="dropdown user user-menu">
                    <a href="javascript:void();" class="dropdown-toggle" data-toggle="dropdown">
                        <span class="hidden-xs"><i class="fa fa-user"></i> <?php echo $admin_name; ?></span>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- User image -->
                        <li class="user-header">
                            <p><?php echo $admin_name ?> - <?php echo $admin_role; ?></p>
                        </li>
                        <!-- Menu Footer-->
                        <li class="user-footer">
                            <div class="pull-left">
                                <a href="password.php" class="btn btn-default btn-flat">Update Password</a>
                            </div>
                            <div class="pull-right">
                                <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                            </div>
                        </li>
                    </ul>
                </li>
                <!-- Control Sidebar Toggle Button -->
            </ul>
        </div>
    </nav>
</header>

<!-- =============================================== -->
<!-- =============================================== -->

<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">

        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="treeview">
                <a href="index.php">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>


            <li class="treeview">
                <a href="javascript:void();">
                    <i class="fa fa-folder text-aqua"></i>
                    <span>Members</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="new_members.php">
                            <i class="fa fa-users text-aqua"></i> New Members
                        </a>
                        <a href="active_members.php">
                            <i class="fa fa-users text-green"></i> Active Members
                        </a>
                        <a href="suspended_members.php">
                            <i class="fa fa-users text-orange"></i> Suspended Members
                        </a>
                        <a href="banned_members.php">
                            <i class="fa fa-users text-red"></i> Banned Members
                        </a>
                         <a href="member.php">
                            <i class="fa fa-users text-lime"></i> All Members
                        </a>
                    </li>

                </ul>
            </li>
            <li class="treeview">
                <a href="javascript:void();">
                    <i class="fa fa-reply text-lime"></i>
                    <span>Receive Request</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="rstarter.php">
                            <i class="fa fa-users text-lime"></i> R Starter
                        </a>
                    </li>
                    <li>
                        <a href="rregular.php">
                            <i class="fa fa-users text-lime"></i> R Regular
                        </a>
                    </li>
                    <li>
                        <a href="rstandard.php">
                            <i class="fa fa-users text-lime"></i> R Standard
                        </a>
                    </li>
                    <li>
                        <a href="rpremium.php">
                            <i class="fa fa-users text-lime"></i> R Premium
                        </a>
                    </li>
                    <li>
                        <a href="rclassic.php">
                            <i class="fa fa-users text-lime"></i> R Classic
                        </a>
                    </li>
                    <li>
                        <a href="rpro.php">
                            <i class="fa fa-users text-lime"></i> R Pro
                        </a>
                    </li>
                    <li>
                        <a href="rultimate.php">
                            <i class="fa fa-users text-lime"></i> R Ultimate
                        </a>
                    </li>
                    <li>
                        <a href="rmaster.php">
                            <i class="fa fa-users text-lime"></i> R Master
                        </a>
                    </li>
                    <li>
                        <a href="receivemerge.php">
                            <i class="fa fa-users text-lime"></i> All Receive Merge
                        </a>
                    </li>
                    <li>
                        <a href="receive.php">
                            <i class="fa fa-users text-lime"></i> All To Receive
                        </a>
                    </li>
                </ul>
            </li>
            <li class="treeview">
                <a href="javascript:void();">
                    <i class="fa fa-share text-orange"></i>
                    <span>Payout Request</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="pstarter.php">
                            <i class="fa fa-users text-orange"></i> P Starter
                        </a>
                    </li>
                    <li>
                        <a href="pregular.php">
                            <i class="fa fa-users text-orange"></i> P Regular
                        </a>
                    </li>
                    <li>
                        <a href="pstandard.php">
                            <i class="fa fa-users text-orange"></i> P Standard
                        </a>
                    </li>
                    <li>
                        <a href="ppremium.php">
                            <i class="fa fa-users text-orange"></i> P Premium
                        </a>
                    </li>
                    <li>
                        <a href="pclassic.php">
                            <i class="fa fa-users text-orange"></i> P Classic
                        </a>
                    </li>
                    <li>
                        <a href="ppro.php">
                            <i class="fa fa-users text-orange"></i> P Pro
                        </a>
                    </li>
                    <li>
                        <a href="pultimate.php">
                            <i class="fa fa-users text-orange"></i> P Ultimate
                        </a>
                    </li>
                    <li>
                        <a href="pmaster.php">
                            <i class="fa fa-users text-orange"></i> P Master
                        </a>
                    </li>
                    <li>
                        <a href="payoutmerge.php">
                            <i class="fa fa-users text-orange"></i> All Payout Merge
                        </a>
                    </li>
                    <li>
                        <a href="payout.php">
                            <i class="fa fa-users text-orange"></i> All To Payout
                        </a>
                    </li>
                </ul>
            </li>
             <li class="treeview">
                <a href="javascript:void();">
                    <i class="fa fa-money text-red"></i>
                    <span>Payment</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="payment.php">
                            <i class="fa fa-users text-red"></i> Payment
                        </a>
                        <a href="request.php">
                            <i class="fa fa-users text-red"></i> All Ruquest
                        </a>
                    </li>
                </ul>
            </li>
            <li class="treeview">
                <a href="javascript:void();">
                    <i class="fa fa-folder text-lime"></i>
                    <span>Other Controls</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <?php
                        if($_SESSION['admin_role'] === "admin"){
                        ?>
                        <a href="activation.php">
                            <i class="fa fa-users text-aqua"></i> Activation Code
                        </a>
                        <a href="changerequest.php">
                            <i class="fa fa-exchange text-aqua"></i> Chage Request
                        </a>
                        <?php
                        }
                        ?>
                        <a href="referrals.php">
                            <i class="fa fa-users text-green"></i> Referrals
                        </a>
                        <a href="bonus.php">
                            <i class="fa fa-users text-green"></i> Withdrawal Bonus
                        </a>
                        <a href="payment.php">
                            <i class="fa fa-users text-red"></i> Payment Proof
                        </a>
                    </li>
                </ul>
            </li>
             <li class="treeview">
                <a href="javascript:void();">
                    <i class="fa fa-money text-lime"></i>
                    <span>Wallet</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="wallet.php">
                            <i class="fa fa-users text-aqua"></i> Wallet
                        </a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="javascript:void();">
                    <i class="fa fa-bullhorn text-lime"></i>
                    <span>Advert</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <li>
                        <a href="advert_member.php">
                            <i class="fa fa-users text-aqua"></i> Member
                        </a>
                        <a href="advert.php">
                            <i class="fa fa-users text-green"></i> Advert
                        </a>
                        <a href="adver_payment.php">
                            <i class="fa fa-users text-red"></i> Payment
                        </a>
                    </li>
                </ul>
            </li>
            <?php
            if($_SESSION['admin_role'] === "admin"){
                ?>
                <li class="treeview">
                    <a href="javascript:void();">
                        <i class="fa fa-folder text-green"></i>
                        <span>Admin</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li>
                            <a href="admin.php?act=add">
                                <i class="fa fa-plus"></i> Add new Admin
                            </a>
                        </li>
                        <li>
                            <a href="admin.php">
                                <i class="fa fa-file-o"></i> All Admin
                            </a>
                        </li>
                        <li>
                            <a href="admin.php?act=edit">
                                <i class="fa fa-edit"></i> Edit Admin
                            </a>
                        </li>
                        <li>
                            <a href="admin.php?act=del">
                                <i class="fa fa-trash-o"></i> Delete Admin
                            </a>
                        </li>
                    </ul>
                </li>

                <?php
            }
            ?>
            <li><a href="password.php"><i class="fa fa-circle text-blue"></i> <span>Update Password</span></a></li>

            <li class="treeview">
                <a href="settings.php">
                    <i class="fa fa-cog"></i> <span>Settings</span>
                </a>
            </li>

            <li><a href="logout.php"><i class="fa fa-sign-out text-red"></i> <span>Logout</span></a></li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>