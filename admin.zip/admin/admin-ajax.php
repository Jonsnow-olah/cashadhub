<?php
  require_once '../config/config.php';
  if(!admin())
  {
    header("location:login.php");
    exit();
  }

  if(isset($_GET['c-0'])){
      $id = $_GET['id'];
      $semester = settings("semester");
      $session = settings("session");
      $sql = $db->query("SELECT NULL FROM course_reg WHERE allocated = '0' AND course = '$id'");
      $rows = $sql->rowCount();
      $sql->closeCursor();

      echo $rows;
      exit();
  }