<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b><?php echo site_name(); ?>.</b>
  </div>
  <strong>Copyright &copy; <?php echo date("Y"); ?> - All rights reserved.</strong>
 </footer>

  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<script type="text/javascript" src="../libs/jquery/jquery.min.js"></script>
<script type="text/javascript" src="../libs/bootstrap/js/bootstrap.min.js"></script>

<?php
    if(isset($page)){
        ?>
        <script type="text/javascript" src="libs/datepicker/jquery.plugin.min.js"></script>
        <script type="text/javascript" src="libs/datepicker/jquery.datepick.min.js"></script>

        <script>
            $('#popupDatepicker').datepick({
                dateFormat: 'dd-M-yyyy',
                minDate: new Date()
            });
        </script>

        <?php
    }


    if(isset($ajaxx)){
        ?>
        <script type="text/javascript">
            $(document).ready(function () {
               let ajax_url = 'ex_ajax.php';
               $("#ed").change(function (e) {
                  let ed = $(this).val();
                  let ex = $("#et").val();

                  if(ed != '' & et != ''){
                      let courses = get_course(ed,et);
                      $("#course").html(courses);
                  }
               });


                $("#et").change(function (e) {
                    let ed = $("#ed").val();
                    let ex = $("#et").val();

                    if(ed != '' & et != ''){
                        let courses = get_course(ed,et);
                        $("#course").html(courses);
                    }
                });
               function get_course(exam_date,exam_time) {
                   $.ajax({
                       url: ajax_url,
                       type: 'get',
                       data: {
                           'fetch_course': '',
                           'exam_date': exam_date,
                           'exam_time': exam_time
                       },
                       success: function (e) {
                           return e;
                       }
                   });
               }
            });
        </script>
        <?php
    }



    if(isset($page_special)){
        ?>
        <script type="text/javascript">
            $(document).ready(function () {
                $("#total-centers").on("change",function (e) {
                    let total_centers = $(this).val();
                    $(".extra-fields").html('');


                    for(let i = 0; i < total_centers; i++){

                        let j = i+1;
                        let fields = $(".cloned").html();

                        fields = fields.replace("$$$",j);
                        fields = fields.replace("$$$",j);
                        fields = fields.replace("$$$",j);
                        fields = fields.replace("$$$",j);

                        $(".extra-fields").append(fields);
                    }
                })
            });
        </script>
        <?php
    }
?>


<script type="text/javascript">
    $(document).ready(function () {
        $("#et").change(function () {            
           var ed = $("#ed").val();
           var et = $("#et").val();

           if(ed == ""){
            return;
           }

           $.ajax({
                'url': 'ex_ajax.php',
                'type': 'get',
                'data': {
                    'fetch_course': '',
                    'exam_date': ed,
                    'exam_time': et
                },
                success: function (f) {
                    //console.log(f);
                    $("#course").html(f);
                }
           });
        });



        $("#ed").change(function () {            
           var ed = $("#ed").val();
           var et = $("#et").val();

           if(et == ""){
            return;
           }

           $.ajax({
                'url': 'ex_ajax.php',
                'type': 'get',
                'data': {
                    'fetch_course': '',
                    'exam_date': ed,
                    'exam_time': et
                },
                success: function (f) {
                    //console.log(f);
                    $("#course").html(f);
                }
           });
        });


        $("#course").blur(function () {            
           var ed = $("#ed").val();
           var et = $("#et").val();
           var course = $("#course").val();

           if(et == ""){
            return;
           }
           if(ed == ""){
            return;
           }

           $.ajax({
                'url': 'ex_ajax.php',
                'type': 'get',
                'data': {
                    'fetch_center': '',
                    'exam_date': ed,
                    'exam_time': et,
                    'course_id': course
                },
                success: function (f) {
                    //console.log(f);
                    $("#center_id").html(f);
                }
           });
        });



        $("#center_id").blur(function () {            
           var ed = $("#ed").val();
           var et = $("#et").val();
           var course = $("#course").val();
           var center_id = $("#center_id").val();

           if(et == ""){
            return;
           }
           if(ed == ""){
            return;
           }

           if(course == ""){
            return;
           }

           if(center_id == ""){
            return;
           }

           $.ajax({
                'url': 'ex_ajax.php',
                'type': 'get',
                'data': {
                    'att_inv': '',
                    'exam_date': ed,
                    'exam_time': et,
                    'course_id': course,
                    'center_id': center_id
                },
                'dataType': 'JSON',
                success: function (f) {
                    //console.log(f);
                    $("#old_inv").val(f.inv);
                    $("#old_att").val(f.att);
                }
           });
        });
    });
</script>
<script src="lib/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="lib/fastclick/fastclick.js"></script>
<script src="lib/DataTables/datatables.min.js"></script>
<script type="text/javascript" src="lib/trumbowyg/dist/trumbowyg.min.js"></script>
<script type="text/javascript" src="lib/datepicker/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$('#tables').DataTable();



        $("#c_all").click(function(e) {
           var a = $(this).prop("checked");
           $(".cbox").prop("checked",a);
        });

        $(".btn-delete-cats").click(function(event) {
            /* Act on the event */
            //console.log("a");
            var a  = confirm("Are you sure you want to delete this category \n(All questions will be deleted)?");
            if(a == false){
                event.preventDefault();
                return false;
            }

            //btn-delete-question
        });


        $(".btn-delete-question").click(function(event) {
            /* Act on the event */
            //console.log("a");
            var a  = confirm("Are you sure you want to delete this question?");
            if(a == false){
                event.preventDefault();
                return false;
            }

            //btn-delete-question
        });


        $(".btn-delete-result").click(function(event) {
            /* Act on the event */
            //console.log("a");
            var a  = confirm("Are you sure you want to delete the selected results??");
            if(a == false){
                event.preventDefault();
                return false;
            }

            //btn-delete-question
        });

        //btn-delete-result


	});
</script>

<?php
    if(isset($page) && $page == "gen"){
        ?>
        <script type="text/javascript">
            var oTable;
            $(document).ready(function () {
                $('#generates').submit( function() {
                    var sData = oTable.$('input').serialize();
                    $("#edd").val(sData);
                    //alert( "The following data would have been submitted to the server: \n\n"+sData );
                    //return false;
                } );

                oTable = $("#tabless").dataTable();
            });
        </script>
        <?php
    }
?>
<!-- select2 -->
        <script src="js/select2.full.js"></script>
        <!-- select2 -->
        <script>
            $(document).ready(function () {
                $(".select2_single").select2({
                    placeholder: "Select an option",
                    allowClear: true
                });
                $(".select2_group").select2({});
                $(".select2_multiple").select2({
                    maximumSelectionLength: 4,
                    placeholder: "With Max Selection limit 4",
                    allowClear: true
                });
            });
        </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.trumbowyg').trumbowyg();
        });
    </script>
<script src="js/admin.js"></script>
<script type="text/javascript" src='js/main.js'></script>

<script type="text/javascript" src="js/game.js"></script>
<script src="js/app.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="js/demo.js"></script>
<script>
    if(window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
  }
</script>
</body>
</html>