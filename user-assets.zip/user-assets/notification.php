<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>
<html  >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  
  <title>Notification</title>
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  <link rel="preload" as="style" href="../assets/mobirise/css/mbr-additional.css">
  <link rel="stylesheet" href="../assets/mobirise/css/mbr-additional.css" type="text/css">
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lemonada:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>
  <link rel="stylesheet" href="css/user.css">
  <link rel="stylesheet" href="css/profile.css">
  <link rel="stylesheet" href="css/notification.css">
  <link rel="stylesheet" href="css/all.css">

</head>
<body>

    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>

        <!-- nav links -->
        <?php require 'inc/nav.php' ?>
        </header>
        
        <main class="dashboard">
           <div class="content-box">
               <div class="head-content">
                    <h1 class="notify-head">Notification</h1>
                    <div class="delete">
                        <i class="fas fa-trash-alt"></i>
                        <button class="cancel">Cancel</button>
                    </div>
               </div>
             
              
              
                <!-- message box section -->
                <div class="msg-box">
                    <!-- message head section -->
                     <div class="msg-head">
                         <div class="box"></div>
                         <button class="msg-title">Welcome to CashAdHub</button>
                         <div class="date-trash">
                            <p class="date">12-08-2020</p>
                            <input type="checkbox" name="" id="">
                        </div>
                     </div>
                     <!-- message body section -->
                     <div class="msg-body">
                         <p class="msg">This is a message Welcoming you to CashadHub.
                             it is nice doing business with you. We hope we are able to 
                             please you in all ways.Pleae always follow instructions given to you on CashAdHub and go to the policy page to know how we operate and also to know about our rules and regulations. CashAdHub is a member to member payment platform, other features like earning via Adverts and also advertsing your products and goods on our platform is on the way, also don't forget you can enroll to learn digital skills on CashAdHub. The enrollment form will be out soon, you too can also build a website like this if you have passion for programming, and there are other digital skills available as well. Hang on tight Amigo!! 
                         </p>
                     </div>
                </div>

                <!-- delete button -->
                <div class="delete-box">
                    <button class="delete-btn">Delete</button>
                </div>
               
           </div>
        </main>

        <footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="../user-assets/img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="https://twitter.com/cashadHub?s=09" target="_blank"><img src="../user-assets/img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="https://www.instagram.com/official_cashadHub?r=nametag" target="_blank"><img src="../user-assets/img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="../user-assets/img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="https://Facebook.com/officialcashadHub" target="_blank" href="https://m.Facebook.com/officialcashadHub"><img src="../user-assets/img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:tee.jhay1@gmail.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; 2020 <span>CashadHub</span></p>
            </div>
        </footer>

    </div>


  <script src="../user-assets/javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="javascript/notify.js"></script>
  <script src="../assets/theme/js/script.js"></script>
  
  
  </body>
</html>