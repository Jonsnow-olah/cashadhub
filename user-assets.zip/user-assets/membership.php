<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>
<html  >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  
  <title>Membership</title>
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  
  
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lemonada:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>
  <link rel="stylesheet" href="css/user.css">
  <link rel="stylesheet" href="css/membership.css">
  <link rel="stylesheet" type="text/css" href="../lib/bootstrap/css/bootstrap.min.css">


</head>
<body>

    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>

        <!-- nav links -->
        <?php require 'inc/nav.php' ?>
        </header>

        <main class="dashboard">
            <div class="top-box">
                <div class="box-one">
                    <p class="title">Membership Plan</p>
                </div>
                <div class="box-two">
                    <p class="c-plan">Current Plan</p>
                    <p class="level-status"><?php echo $levelrs["level"]; ?></p>
                </div>
            </div>
            <!-- level box -->
            <div class="content-box">
                <!-- starter plan -->
                <div class="plan-box">
                    <div class="plan-box-top">
                        <p class="plan">Starter</p>
                        <?php
                        if($mylevel < 1){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 1){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 1){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">4 referrals</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>500</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">12hrs</p>
                        </div>
                    </div>

                </div>
                <!-- regular plan -->
                <div class="plan-box">
                    <div class="plan-box-top">
                        <p class="plan">Regular</p>
                        <?php
                        if($mylevel < 2){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 2){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 2){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">Optional</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>1000</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">24hrs</p>
                        </div>
                    </div>
                </div>
                <!-- Standard plan -->
                <div class="plan-box">
                     <div class="plan-box-top">
                        <p class="plan">Standard</p>
                        <?php
                        if($mylevel < 3){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 3){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 3){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">Optional</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>2000</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">2 Days</p>
                        </div>
                    </div>
                </div>
                <!-- premium plan -->
                <div class="plan-box">
                     <div class="plan-box-top">
                        <p class="plan">Premium</p>
                        <?php
                        if($mylevel < 4){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 4){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 4){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">Optional</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>4000</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">4 Days</p>
                        </div>
                    </div>
                </div>
                <!-- Classic plan -->
                <div class="plan-box">
                     <div class="plan-box-top">
                        <p class="plan">Classic</p>
                        <?php
                        if($mylevel < 5){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 5){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 5){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">optional</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>6000</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">5 Days</p>
                        </div>
                    </div>
                </div>
                <!-- pro plan -->
                <div class="plan-box">
                     <div class="plan-box-top">
                        <p class="plan">Pro</p>
                        <?php
                        if($mylevel < 6){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 6){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 6){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">Optional</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>10,000</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">7 Days</p>
                        </div>
                    </div>
                </div>
                <!-- ultimate plan -->
                <div class="plan-box">
                     <div class="plan-box-top">
                        <p class="plan">Ultimate</p>
                        <?php
                        if($mylevel < 7){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 7){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 7){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">Optional</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>16,000</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">8 Days</p>
                        </div>
                    </div>
                </div>
                <!-- master plan -->
                <div class="plan-box">
                     <div class="plan-box-top">
                        <p class="plan">Master</p>
                        <?php
                        if($mylevel < 8){
                        ?>
                        <p class="plan-status">Pending</p>
                        <?php
                        }else if($mylevel == 8){
                        ?>
                        <p class="plan-status active">Active</p>
                        <?php
                        }else if($mylevel > 8){
                        ?>
                        <p class="plan-status text-warning">Pasted</p>
                        <?php
                        }
                        ?>
                        <p class="ref">Optional</p>
                    </div>
                    <div class="plan-box-bottom">
                        <p class="price"><span>&#8358</span>24,000</p>
                        <div class="time-box">
                            <p class="duration">Duration</p>
                            <p class="time">10 Days</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="../user-assets/img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="https://twitter.com/cashadHub?s=09" target="_blank"><img src="../user-assets/img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="https://www.instagram.com/official_cashadHub?r=nametag" target="_blank"><img src="../user-assets/img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="../user-assets/img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="https://Facebook.com/officialcashadHub" target="_blank" href="https://m.Facebook.com/officialcashadHub"><img src="../user-assets/img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:tee.jhay1@gmail.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; 2020 <span>CashadHub</span></p>
            </div>
        </footer>

    </div>

  <script src="../user-assets/javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="../assets/theme/js/script.js"></script>
  
  
  </body>
</html>