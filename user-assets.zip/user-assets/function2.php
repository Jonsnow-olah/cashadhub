<?php
if(!isset($_SESSION["username"])){
  header("location: ../login.php");
}else{
  $username = $_SESSION["username"];
  $password = $_SESSION["password"];
}
$recUserId = "";
$sql = "SELECT * from cashad_hub_users where username = '$username' ";
$result = $conn->query($sql)or
die(mysqli_error($conn));
$rs = $result->fetch_assoc();

$passport = $rs["passport"];

$userid = $rs["userid"];

$mylevel = $rs["level"];
$myId = $rs["id"];
$myUserId = $rs["userid"];


$level = "SELECT cashad_hub_users.level, cashad_hub_levels.level as level, cashad_hub_levels.payment as payment from cashad_hub_users inner join cashad_hub_levels on cashad_hub_users.level = cashad_hub_levels.id where cashad_hub_users.userid = '$myUserId' ";

$levelres = $conn->query($level)or
die(mysqli_error($conn));

$levelrs = $levelres->fetch_assoc();
$amount = $levelrs["payment"];
//Select Bank Details
$bank = "SELECT * from cashad_hub_user_bank where userid = '$myUserId' ";
$bankres = $conn->query($bank)or
die(mysqli_error($conn));

$bkrs = $bankres->fetch_assoc();


//Select Wallet Details

$wallet = "SELECT * from cashad_hub_ledger where userid = '$myUserId' ";
$walletres = $conn->Query($wallet)or
die(mysqli_error($conn));
$walletrs = $walletres->fetch_assoc();
?>