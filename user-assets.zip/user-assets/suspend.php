<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>

<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
        <!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
        <!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
        <!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<html  >

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Dashboard | Activate</title>
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  <link rel="stylesheet" href="../assets/mobirise/css/mbr-additional.css" type="text/css">
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>
  <link rel="stylesheet" href="css/user.css">
  <link rel="stylesheet" href="css/payment.css">
  <link rel="stylesheet" href="css/suspend.css">

</head>
<body>
    <!--[if lt IE 7]>
                    <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
                <![endif]-->
    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>

        <!-- nav links -->
            <?php require 'inc/nav.php' ?>
        </header>
        <?php
          if(isset($_GET["action"])){
            $updateMerge = "UPDATE cashad_hub_users set merge = 0 where user_id = '$userid' ";
            $updateMergeRes = $conn->query($updateMerge)or
            die(mysqli_error($conn));

            
            $updateMerge2 = "UPDATE cashad_hub_merge set status = 'Available', pickerid = 'NULL', date_time = 'NULL' ";
            $updateMerge2Res = $conn->query($updateMerge2)or
            die(mysqli_error($conn));

            if ($updateMergeRes === TRUE && $updateMerge2Res == TRUE) {
              echo "<script>alert('Update successfylly');</script>";
            }
          }



        ?>
        <main class="dashboard">
            <!-- profile box section -->
            <div class="profile-box">
                <div class="profile">
                    <div id="dp">
                        <img src="<?php echo '../passports/'.$rs['passport']; ?>" alt="">
                    </div>
                    <h6 class="username"><?php echo $rs["username"] ?></h6>
                    <p class="id">ID:<?php echo $rs["user_id"] ?></p>
                </div>
                <div class="profile-status">
                    <h3 >STATUS</h3>
                    <p class="status"><?php echo $rs["status"]; ?></p>
                </div>
            </div>

            <!-- payment box section -->
            <div class="payment-box">
                <div class="pay">
                    <div>
                        <a href="dashboard.php"><button class="merge cant-pay suspend "><i class="fas fa-user-unlock"></i> Activate</button></a>
                    </div>
                </div>
            </div> 

            <!-- note section -->            
                <div class="note">
                    <p><span>Note:</span>
                        Clicking on the activation button would give you access to continue from your previous plan, you are only 
                        allowed to opt-out payment one more time,cancelling payment at third time would lead to blocking of your account permanently...
                </div>            

        </main>

         <!-- footer section  -->
         <?php require_once 'inc/footer.php'; ?>
       
    </div>




  <script src="javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="../assets/theme/js/script.js"></script>
  

  <input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience. Read our <a href='privacy.html'>cookie policy</a>.">
  <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a>
  </div>
   <input name="animation" type="hidden">  
  </body>
</html>