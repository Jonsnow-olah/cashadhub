<div class="nav-links">
    <div class="dp">
        <img src="<?php echo '../passports/'.$rs['passport']; ?>" alt="">
        <h5><?php echo $rs["username"] ?></h5>
    </div>
    <ul>
        <li><i class="fas fa-tachometer-alt"></i><a href="dashboard">Dashboard</a></li>
        <li><i class="fas fa-coins"></i><a href="wallet">My Wallet</a></li>
        <li><i class="fas fa-award"></i><a href="membership" id="status"><span>Membership</span> <span><?php echo $levelrs["level"]; ?></span></a></li>
        <li><i class="fal fa-user-circle"></i><a href="profile">Profile</a></li>
        <li><i class="fad fa-envelope"></i><a href="notification">Notification</a></li>
        <li><i class="fas fa-users"></i><a href="affiliate">Affiliate</a></li>
        <li><i class="fad fa-ad"></i><a href="advertpage">Advert Page</a></li>
        <li><i class="far fa-sign-in-alt"></i><a href="logout">Logout</a></li>
    </ul>
</div>