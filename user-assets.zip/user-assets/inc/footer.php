<footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="#"><img src="img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="#"><img src="img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="#"><img src="img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:support@cashadhub.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; 2020 <span>CashadHub</span></p>
            </div>
        </footer>