<div class="nav-links">
    <div class="dp">
        <img src="<?php echo '../passports/'.$rs['passport']; ?>" alt="">
        <h5><?php echo $rs["username"] ?></h5>
    </div>
    <ul>
    	<li><i class="far fa-sign-in-alt"></i><a href="payment.php">Payment</a></li>
        <li><i class="far fa-sign-in-alt"></i><a href="logout.php">Logout</a></li>
    </ul>
</div>