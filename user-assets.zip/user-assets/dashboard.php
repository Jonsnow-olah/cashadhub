<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<html  >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Dashboard</title>
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  <!--<link rel="stylesheet" href="../assets/mobirise/css/mbr-additional.css" type="text/css"> -->
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>
  <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/payment.css">
  <link rel="stylesheet" href="css/user.css">
   <link rel="stylesheet" href="../assets/reset/CSS-reset/loader.css">
</html>
</head>
<body>
  
  <section class="loader">
            <div class="load-box">
                <div class="load"></div>
                <div class="load"></div>
                <div class="load"></div>
                <div class="load"></div>
                <div class="load"></div>
                <div class="load"></div>
                <div class="load"></div>
                <div class="load"></div>
            </div>
        </section>
    
    <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>
        <!-- nav links -->
            <?php require 'inc/nav.php' ?>
        </header>

        <!-- dashboard section -->
        <main class="dashboard">
            <!-- profile box section -->
            <div class="profile-box">
                <div class="profile">
                    <div id="dp">
                        <img src="<?php echo '../passports/'.$rs['passport']; ?>" alt="">
                    </div>
                    <h6 class="username"><?php echo $rs["username"]; ?></h6>
                    <p class="id">ID:<?php echo $rs["userid"]; ?></p>
                </div>
                <div class="profile-status">
                    <h3 >STATUS</h3>
                    <p class="status"><?php echo $rs["status"]; ?></p>
                </div>
            </div>

            <!-- payment box section -->
            <div class="payment-box">
                <div class="pay">
                    <div>
                        <?php
                          $dur = "";
                          $readTime = "";
                          $paymentApp = "";
                          $cehcMerge = "SELECT * from cashad_hub_merge where userid = '$userid' ";
                          $checkMergeRes = $conn->query($cehcMerge)or
                          die(mysqli_error($conn));

                          if($checkMergeRes->num_rows > 0){
                            $checkMergeRs = $checkMergeRes->fetch_assoc();
                            $merge = $checkMergeRs["merge"];
                            $type = $checkMergeRs["type"];
                            if($merge == "nill" and $type == "Payout"){
                        ?>
                            <a href="javascript:void();" onclick="showNote();" class="merge"><i class="fas fa-user-friends"></i> Merge</a>
                        <?php
                            }else if($merge == "nill" and $type == "Receive"){
                        ?>
                            <a href="javascript:void();" onclick="showNotes();" class="merge"><i class="fas fa-user-friends"></i> Merge</a>
                        <?php
                            }
                          }else{

                                $balance = $walletrs["withdraw"];
                                if($balance > 0){    
                            ?>
                              <a href="javascript:void();" onclick="widthDraw()" class="merge"><i class="fas fa-user-friends"></i> Merge</a>
                            <?php
                              }else{
                            ?>
                            <form action="payment" method="post">
                              <input type="hidden" name="userid" value="<?php echo($rs["userid"]); ?>">
                              <button class="merge" name="merge"><i class="fas fa-user-friends"></i> Merge</button>
                            </form>
                            <?php
                              }
                            }
                        ?>
                    </div>
                </div>
            </div>
            <script>
              function showNote(){
                alert("You already have request submitted");
              }
              function widthDraw(){
                alert("You must withdraw your current balance before you can request for merging");
              }
              function showNotes(){
                alert("You have request for a withdarwall, kindly wait for the request to be proccess");
              }
            </script>
            <!-- note section -->            
            <div class="note">
                    <p><span>Note:</span>
                        If you click on the merge button you will recieve details of the customer you are to pay to, bearing 
                        in mind that there is a designated time in which you are to meet up payment, not meeting up with payment after 
                        the time frame could lead to suspension of your account...</p>
            </div>
            <div class="note" id="notes">
              <div class='alert alert-info'>Click on the merge button above to check the available member for merging</div>
            </div>
            
        </main>

        <!-- footer section -->
        <footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="https://twitter.com/cashadHub?s=09" target="_blank"><img src="img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="https://www.instagram.com/official_cashadHub?r=nametag" target="_blank"><img src="img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="https://Facebook.com/officialcashadHub" target="_blank" href="https://m.Facebook.com/officialcashadHub"><img src="img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:tee.jhay1@gmail.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; 2020 <span>CashadHub</span></p>
            </div>
        </footer>

       
    </div>




  <script src="javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="../assets/theme/js/script.js"></script>
  <script src="../assets/reset/JSreset/loader.js"></script>
  
  
<input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience. Read our <a href='privacy.html'>cookie policy</a>.">
   <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
    <input name="animation" type="hidden">
<script>
// Set the date we're counting down to
var countDownDate = new Date("<?php echo($approvedDate); ?>").getTime(); //"July 15, 2020 07:42:49"
//countDownDate.setHours(countDownDate.getHours() + 5);
// Update the count down every 1 second
var x = setInterval(function() {

    // Get todays date and time
    var now = new Date().getTime();
    
    // Find the distance between now an the count down date
    var distance = countDownDate - now;
    
    // Time calculations for days, hours, minutes and seconds
    var days = (Math.floor(distance / (1000 * 60 * 60 * 24))) * (24);
    var hours = (Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))) + days;
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);
      hours = checkTime(hours);
      minutes = checkTime(minutes);
        seconds = checkTime(seconds);
    // Output the result in an element with id="demo"
    document.getElementById("hours").innerHTML = hours;
    document.getElementById("minutes").innerHTML = minutes;
    document.getElementById("seconds").innerHTML = seconds;
    
    // If the count down is over, write some text 
    if (distance < 0) {
        clearInterval(x);
        document.getElementById("hours").innerHTML = "11";
        document.getElementById("minutes").innerHTML = "11";
        document.getElementById("seconds").innerHTML = "11";
        //document.getElementById("cantpay").innerHTML = '<i class="far fa-sign-in-alt"></i><a href="javascript:void();" onclick="paidNot();">Paid</a>';
        document.getElementById("notes").innerHTML = "<div class='alert alert-info'>Click on the merge button above to check the available memeber for mergin</div>";
    }
}, 1000);
function checkTime(i) {
      if (i < 10) {
        i = "0" + i;
      }
      return i;
    }
</script>
</body>
</html>