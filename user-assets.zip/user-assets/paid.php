<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>
<html class="no-js"> <!--<![endif]-->
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Proof of Payment | CashAdHub</title>
  <link rel="stylesheet" href="../lib/font-awesome/font-awesome.min.css"> 
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  <!--<link rel="stylesheet" href="../assets/mobirise/css/mbr-additional.css" type="text/css">-->
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>

  <link rel="stylesheet" href="css/user.css">
  <link rel="stylesheet" href="css/payment.css">
  <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">

</head>
<body>
    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>

        <!-- nav links -->
            <?php require 'inc/nav.php' ?>
        </header>
<?php
            if(isset($_GET["payId"])){
              $payId = mysqli_real_escape_string($conn,$_GET["payId"]);
              $benId = mysqli_real_escape_string($conn,$_GET["benId"]);
              $amount = mysqli_real_escape_string($conn,$_GET["amount"]);
              }
            ?>
        <!-- dashboard section -->
        <main class="dashboard">
            <!-- profile box section -->
            <div class="profile-box">
                <div class="profile">
                    <div id="dp">
                        <img src="<?php echo '../passports/'.$rs['passport']; ?>" alt="">
                    </div>
                    <h6 class="username"><?php echo $rs["username"]; ?></h6>
                    <p class="id">ID:<?php echo $rs["userid"]; ?></p>
                </div>
                <div class="profile-status">
                    <h3 >STATUS</h3>
                    <p class="status"><?php echo $rs["status"]; ?></p>
                </div>
            </div>
            
            <?php
    if(isset($_POST["upload"])){
      if(empty($_FILES["proof"]["name"])){
        set_flash("No file select","danger");
        }else{
          $target_file = "../payment/".basename($_FILES["proof"]["name"]);
          $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
          $check = getimagesize($_FILES["proof"]["tmp_name"]);
          if($check === false) {
            set_flash("File selected is not and image","danger");
            }else if($_FILES["proof"]["size"] > 500000) {
              set_flash("File selected is too large, should not be more than 200kb","danger");
            }else if($imageFileType != "jpg" and $imageFileType != "jpeg" and $imageFileType != "png") {
              set_flash("Only jpeg, jpg and png images allow","danger");
            }else{
              $passport = mysqli_real_escape_string($conn,$_FILES["proof"]["name"]);
              $number = rand(9,999999);
              $ext = explode('.', $passport);
              $ext = end($ext);
              $newfilename = $number.".";
              $newfilename = $newfilename.$ext;
              $proof = htmlspecialchars($newfilename);
              $target = "../payment/".$newfilename;
              $insertPayment = "INSERT into cashad_hub_payment (payer,beneficiary,amount,paid,received,file,action) values ('$payId','$benId','$amount',1,0,'$proof','Pending')";
              $insertPaymentRes = $conn->query($insertPayment)or
              die(mysqli_error($coon));
              move_uploaded_file($_FILES['proof']['tmp_name'], $target);
              if($insertPaymentRes === TRUE){
                  $getPayment = "SELECT payment from cashad_hub_merge where userid = '$benId' and status = 'Merge' and merge = 'Yes' ";
                  $getPaymentRes = $conn->query($getPayment)or
                  die(mysqli_error($conn));
                  if($getPaymentRes->num_rows > 0){
                    $getPaymentRs = $getPaymentRes->fetch_assoc();
                    $newAmount = $getPaymentRs["payment"] + $amount;
                    //Update Payment to Request
                    $updatePayment = "UPDATE cashad_hub_merge set payment = '$newAmount' where userid = '$benId' and status = 'Merge' and merge = 'Yes' ";
                    $updatePaymentRes = $conn->query($updatePayment)or
                    die(mysqli_error($conn));
                    if($updatePaymentRes === TRUE){
                        set_flash("Proof of payment uploaded successfully.<br>Contact the reciever to approved your payment","success");
                }else{
                set_flash("There was error in uploading proof of payment","danger");
                }
            }
          }
        }
    }
}
    ?>
            <!-- payment box section -->
            <div class="payment-box">
                <div class="pay">
                    <h2 style="color: #fff;">Upload Proof of Payment</h2>
                </div>
            </div>
            <!-- note section -->            
            <div class="note">
                <p><span>Note:</span>
                    Uploading fake proof of payment or sending a fake alert will autoatically diactive your account.  Any fraudulent act or action found by you will automatically diactivate your account from this platform
                <div class="alert alert-danger">
                    Remeber! Uploading fake proof or sending fake alert to the receiver will automatically diactivate your account
                </div>
            </div>
            <div class="note">
              <div class="row">
                <div class="col-lg-12">
                  <form class="" action="" method="post" enctype="multipart/form-data">
                    <div class="form-header">
                      <h4 class="text-center" style="font-weight: bold; margin-bottom: 20px;">Upload Proof of Payment</h4>
                    </div>
                    <span><?php echo flash(); ?></span>
                    <div class="form-group">
                      <label>Image for proof of payment</label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-image"></i></span>
                        <input class="form-control" type="file" name="proof" required="required">
                      </div>
                    </div>
                    <div class="form-group">
                        <div class="button-group">
                          <?php
                              $checPayment = "SELECT * from cashad_hub_payment where payer = '$payId' and beneficiary = '$benId' and paid = 1 ";
                              $checPaymentRes = $conn->query($checPayment)or
                              die(mysqli_error($conn));

                              if($checPaymentRes->num_rows > 0){
                          ?>
                          <div class="col-sm-12 text-center" id="upload">
                            <button onclick="paidAvailable();" class="btn btn-success w-100 disabled" style="width: 100%;">Upload Proof <i class="fa fa-upload"></i></button>
                          </div>
                          <script>
                            function paidAvailable(){
                              alert('Your have alread submit a proof of payment contact the receiver to aprproved your payment');
                            }
                          </script>
                          <?php
                            }else{
                          ?>
                          <div class="col-sm-12 text-center" id="upload">
                            <button type="submit" name="upload" class="btn btn-success w-100" style="width: 100%;">Upload Proof <i class="fa fa-upload"></i></button>
                          </div>
                          <?php
                            }
                          ?>
                        </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
        <!-- footer section  -->
        <footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="#"><img src="img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="#"><img src="img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="#"><img src="img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:tee.jhay1@gmail.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; <?php echo date("Y"); ?> <span>CashadHub</span></p>
            </div>
        </footer>
       
    </div>
  <script src="javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="../assets/theme/js/script.js"></script>
  

  <input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience. Read our <a href='privacy.html'>cookie policy</a>.">
  <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a>
  </div>
   <input name="animation" type="hidden">

<script>
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
</script>  
  </body>
</html>