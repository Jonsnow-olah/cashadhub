let msgTitle = document.querySelectorAll(".msg-title");
let msgBody = document.getElementsByClassName("msg-body");
let box = document.getElementsByClassName("box");

msgTitle.forEach((title, i) => {
  title.addEventListener("click", () => {
    title.classList.add("color-change");
    msgBody[i].classList.toggle("show-message");
    box[i].classList.add("read");
  });
});

// delete section
let trash = document.querySelector(".fa-trash-alt");
let checkbox = document.querySelectorAll("input[type=checkbox]");
let dates = document.querySelectorAll(".date");
let deletebtn = document.querySelector(".delete-btn");
let cancel = document.querySelector(".cancel");
trash.addEventListener("click", () => {
  for (let i = 0; i < checkbox.length; i++) {
    checkbox[i].classList.add("show-box");
    dates[i].classList.add("hide-date");
  }
  deletebtn.classList.add("show-delete");
  cancel.classList.add("show-cancel");
  trash.classList.add("hide-delete");
});
cancel.addEventListener("click", () => {
  cancel.classList.remove("show-cancel");
  deletebtn.classList.remove("show-delete");
  trash.classList.remove("hide-delete");
  for (let i = 0; i < checkbox.length; i++) {
    checkbox[i].classList.remove("show-box");
    dates[i].classList.remove("hide-date");
  }
});
