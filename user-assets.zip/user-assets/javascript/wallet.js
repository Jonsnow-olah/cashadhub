let nairabalOne = document.querySelectorAll('.naira-bal')[0];
let nairabalTwo = document.querySelectorAll('.naira-bal')[1];
let nairabalThree = document.querySelectorAll('.naira-bal')[2];
let closeEyeOne = document.querySelectorAll('.fa-eye-slash')[0];
let closeEyeTwo = document.querySelectorAll('.fa-eye-slash')[1];
let closeEyeThree = document.querySelectorAll('.fa-eye-slash')[2];
let openEyeOne = document.querySelectorAll('.fa-eye')[0];
let openEyeTwo = document.querySelectorAll('.fa-eye')[1];
let openEyeThree = document.querySelectorAll('.fa-eye')[2];

const  initBal1= nairabalOne.innerHTML;
const  initBal2= nairabalTwo.innerHTML;
const  initBal3= nairabalThree.innerHTML

openEyeOne.addEventListener('click',()=>{
    openEyeOne.classList.add('hide-eye');
    closeEyeOne.classList.add('show-eye');
    nairabalOne.innerHTML= '******';
});

closeEyeOne.addEventListener('click',()=>{
    openEyeOne.classList.remove('hide-eye')
    closeEyeOne.classList.remove('show-eye');
    nairabalOne.innerHTML = initBal1;
});

openEyeTwo.addEventListener('click',()=>{
    openEyeTwo.classList.add('hide-eye');
    closeEyeTwo.classList.add('show-eye');
    nairabalTwo.innerHTML= '******';
});

closeEyeTwo.addEventListener('click',()=>{
    openEyeTwo.classList.remove('hide-eye')
    closeEyeTwo.classList.remove('show-eye');
    nairabalTwo.innerHTML = initBal2;
});

openEyeThree.addEventListener('click',()=>{
    openEyeThree.classList.add('hide-eye');
    closeEyeThree.classList.add('show-eye');
    nairabalThree.innerHTML= '******';
});

closeEyeThree.addEventListener('click',()=>{
    openEyeThree.classList.remove('hide-eye')
    closeEyeThree.classList.remove('show-eye');
    nairabalThree.innerHTML = initBal3;
})
