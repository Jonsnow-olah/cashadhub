// start of hamburger section
const hamburger = document.querySelector('.hamburger');
const ulLinks = document.querySelectorAll('.nav-links ul li');
const navLink = document.querySelector('.nav-links');
const shortLine = document.querySelector('.line:nth-child(2)');
const longLine = document.querySelectorAll('.line');

hamburger.addEventListener('click', ()=>{
    navLink.classList.toggle('open');
    longLine.forEach(line =>{
        line.classList.toggle('short');
    });
    shortLine.classList.toggle('long');
    shortLine.classList.remove('short');
    ulLinks.forEach(links => {
        links.classList.toggle('fade');
    });
});


// end of hamgburger section
// start of count down timer
// var merge = document.querySelector('#merge');
// var count =100






// document.addEventListener('DOMContentLoaded', ()=>{
//     const mergebtn = document.querySelector('#merge');
//     const timeleft = document.querySelector('#secs');    
//     secs = 59;
//     let id;
//     function countdown(){
//         if(id){
//             clearInterval(id)
//         }
//         mergebtn.setAttribute('disable',true)
//         id = setInterval(function(){
//             if(secs === 0){
//                 clearInterval(id);
//                 timeleft.innerHTML = 'none';
//                 alert('time our')
//             }
//             timeleft.innerHTML = secs;
//             secs -=1;
//         },1000);
//     }
//     mergebtn.addEventListener('click', countdown);
// })