function copyClipboard(){
    const copyText = document.getElementById('link').innerHTML;
    const textArea = document.createElement('textarea');
    textArea.textContent = copyText;
    document.body.append(textArea);
    textArea.select();
    document.execCommand("copy");
}
 var copyBtn = document.querySelector('.copy-btn');
 copyBtn.addEventListener('click', ()=>{
    copyClipboard();
    alert('Hurray!!! You successfully copied your link...')
 })