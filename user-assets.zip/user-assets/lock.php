<?php
require '../config/config.php';
require 'function2.php';
$text = $_SESSION["text"];
$sql = "SELECT * from cashad_hub_users where userid = '$userid' ";
$result = $conn->query($sql)or
die(mysqli_error());
$rs = $result->fetch_assoc();
$name = mysqli_real_escape_string($conn,$rs["name"]);
$userid = mysqli_real_escape_string($conn,$rs["userid"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <title>User Lock - CashAdHub</title>
  <link rel="shortcut icon" href="../assets/images/cashfo-239x274.png" type="image/x-icon">
  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../lib/font-awesome/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="../css/style-lock.css" rel="stylesheet">
  <link href="../css/style-responsive.css" rel="stylesheet">
</head>
<?php
if(isset($_POST["activate"])){
  $code = mysqli_real_escape_string($conn,$_POST["code"]);
  $act = "SELECT * from cashad_hub_activation where userid = '$userid' and activation = '$code'";
  $actRes = $conn->query($act)or
  die(mysqli_error($conn));

  if($actRes->num_rows > 0){
    $updateStatus = "UPDATE cashad_hub_users set status = 'Active', level = 1, acstatus = 'Activated' where userid = '$userid' ";
    $upRes = $conn->query($updateStatus)or
    die(mysqli_error($conn));

    if($upRes === TRUE){

      $deleteActivation = "DELETE from cashad_hub_activation where userid = '$userid' ";
      $deleteActivationRes = $conn->query($deleteActivation)or
      die(mysqli_error($conn));

      $updateRef = "UPDATE cashad_hub_ref set status = 'Activated' where inviteduserid = '$userid' ";
      $updateRefRes = $conn->query($updateRef)or
      die(mysqli_error($conn));
      
      header("location: dashboard");
    }
  }else{
    set_flash("Invalid activation entered, contact admin for help","danger");
  }
}

?>
<body onload="getTime()">
  <div class="overlay"></div>
  <div class="container" id="container">
    <div id="showtime"></div>
    <div class="col-lg-4 col-lg-offset-4">
      <div class="lock-screen">
        <h2><a data-toggle="modal" href="#myModal"><i class="fa fa-lock"></i></a></h2>
        <p style="margin-bottom: 15px;">UNLOCK</p>
        <span class="alert alert-info" style="padding: 5px;">Click on the Padlock icon above to get your ID</span>
        <!-- Modal -->
        <span><?php echo flash(); ?></span>
        <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Welcome</h4>
              </div>
              <form method="post">
                <div class="modal-body">
                  <div style="width: 80px; height: 80px; margin: auto;"><img class="img-circle" style="width: 100%; height: 100%; object-fit: cover;" src="<?php echo '../passports/'.$rs['passport']; ?>"></div>
                  <p style="margin-top: 5px;"><?php echo $name."<br>ID: ".$userid; ?></p>
                  <p class="alert alert-info">Enter your activation code, or contact any of the numbers for activation code</p>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-code"></i></span>
                    <input type="text" name="code" placeholder="123456789" required="" class="form-control placeholder-no-fix">
                  </div>
                </div>
                <div class="modal-footer centered">
                  <button data-dismiss="modal" class="btn btn-theme04" type="button">Cancel</button>
                  <button class="btn btn-theme03" type="submit" name="activate">Activate</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <!-- modal -->
      </div>
      <!-- /lock-screen -->
    </div>
    <div class="col-lg-6 col-lg-offset-3 admin-contact">
      <h3 class="text-center text-warning"><?php echo $text; ?></h3>
        <h4 class="text-center">Contact any of the numbers belows for help</h4>
        <ul>
          <li>Jon Snow:&nbsp;&nbsp;<a href="https://wa.me/+2348145362848">08145362848</a></li>
          <li>Harchiever:&nbsp;&nbsp;<a href="https://wa.me/+2347033489867">07033489867</a></li>
          <li>A Y:&nbsp;&nbsp;<a href="https://wa.me/+2347055377836">07055377836</a></li>
          <li>Tony:&nbsp;&nbsp;<a href="https://wa.me/+2349019404392">09019404392</a></li>
          <li>SP (Bugs Report):&nbsp;&nbsp;<a href="https://wa.me/+2348030891417">08030891417</a></li>
        </ul>
        <div class="col-sm-12 text-center"><a href="logout" class="btn btn-danger text-center">Logout <i class="fa fa-sign-out"></i></a></div>
        <h4 class="text-center text-info">Alternative Payment mode</h4>
        <ol>
          <li>Bitcoin:-<br>3PQFZFhiaLjWjgBaxKEu7P5taw71XpTJg</li>
          <li>Ethereum:- 0xbf7CB48026D911a1126d29B6285AFC9B0b13D1F</li>
          <p class="text-center">Contact the this number (Jon Snow) <a href="https://wa.me/+2348145362848">08145362848</a> for verification of your Cryptocurrency payment..</p>
        </ol>
    </div>
    <!-- /col-lg-4 -->
  </div>
  <!-- /container -->
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../lib/jquery/jquery.min.js"></script>
  <script src="../lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="../lib/jquery.backstretch.min.js"></script>
  <script type="text/javascript">
  $(document).ready(function(){
    $("body").backstretch([
      "../css/lock1.jpg",
        "../css/lock2.jpg",
        "../css/lock3.jpg",
      ], {duration: 5000, fade: 500});
    
  });
</script>
  <script>
    function getTime() {
      var today = new Date();
      var h = today.getHours();
      var m = today.getMinutes();
      var s = today.getSeconds();
      // add a zero in front of numbers<10
      m = checkTime(m);
      s = checkTime(s);
      document.getElementById('showtime').innerHTML = h + ":" + m + ":" + s;
      t = setTimeout(function() {
        getTime()
      }, 500);
    }

    function checkTime(i) {
      if (i < 10) {
        i = "0" + i;
      }
      return i;
    }
  </script>
</body>

</html>
