<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>
<html  >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>My Wallet</title>
  <link rel="stylesheet" href="../lib/font-awesome/font-awesome.min.css">
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lemonada:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>
  <link rel="stylesheet" href="css/user.css">
  <link rel="stylesheet" href="css/profile.css">  
  <link rel="stylesheet" href="css/payment.css">
  <link rel="stylesheet" href="css/wallet.css">
  <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">

<style>
  .pays{
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    background: rgba(0,0,0,0.4);
    z-index: 2000;
    display: none;
}
.pays .img{
    margin: auto;
    margin-top: 10vh;
}
.pays .img img{
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.close-btn{
    padding: 4px 10px;
    border-radius: 4px;
    position: absolute;
    right: 20px;
    top: 15vh;
    font-size: 30px;
    color: #fff;
    background: red;
    cursor: pointer;
}
.img{
  padding: 10px 30px;
  -webkit-animation-name: zoom;
  -webkit-animation-duration: 0.6s;
  animation-name: zoom;
  animation-duration: 0.6s;
}
@-webkit-keyframes zoom {
    from {-webkit-transform:scale(0)}
    to {-webkit-transform:scale(1)}
}

@keyframes zoom {
    from {transform:scale(0)}
    to {transform:scale(1)}
}
.row div{
  padding: 5px;
  color: #fff;
  font-weight: bold;
}
.row div span{
  color: #000010;
  font-size: 15px;
}
.alert{
  background: #ff9800;
}
</style>
</head>
<body>
    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>

        <!-- nav links -->
        <?php require 'inc/nav.php' ?>
        </header>
        <?php
        
    //If Beneficiary Received
    if(isset($_POST["received"])){
      $payId = mysqli_real_escape_string($conn,$_POST["payId"]);
      $benId = mysqli_real_escape_string($conn,$_POST["benId"]);
      $amount = mysqli_real_escape_string($conn,$_POST["amount"]);
      $level = mysqli_real_escape_string($conn,$_POST["level"]);

      $dur = "";
      if($amount == 500){
        $dur = strtotime("+12 Hours");
      }else if($amount == 1000){
        $dur = strtotime("+24 Hours");
      }else if($amount == 2000){
        $dur = strtotime("+48 Hours");
      }else if($amount == 4000){
        $dur = strtotime("+96 Hours");
      }else if($amount == 6000){
        $dur = strtotime("+120 Hours");
      }else if($amount == 10000){
        $dur = strtotime("+168 Hours");
      }else if($amount == 15000){
        $dur = strtotime("+192 Hours");
      }else if($amount == 24000){
        $dur = strtotime("+240 Hours");
      }
      

      $proTime = date("F d, Y H:i:s",$dur);
      //Fetch Legder Balance
      $printBalance = "SELECT withdraw, savings from cashad_hub_ledger where userid = '$payId' ";
      $printBalanceRes = $conn->query($printBalance)or
      die(mysqli_error($conn));
      $printBalanceRs = $printBalanceRes->fetch_assoc();
      $ledgWithdraw = $printBalanceRs["withdraw"];
      $ledgSavings = $printBalanceRs["savings"];
      //Fetch Legder Balance
      //Fetch Level Withdraw
      $selectWidth = "SELECT withdraw, savings from cashad_hub_levels where id = '$level' ";
      $selectWidthRes = $conn->query($selectWidth)or
      die(mysqli_error($conn));
      $selectWidthRs = $selectWidthRes->fetch_assoc();
      $draw = $selectWidthRs["withdraw"];
      $savings = $selectWidthRs["savings"];
      //Fetch Level Withdraw

      //New Withdraw and Savings
      $newWithdraw = $ledgWithdraw + $draw;
      $newSavings = $ledgSavings + $savings;
      $newLevel = $level + 1;
      //New Withdraw and Savings

      $confirm = "UPDATE cashad_hub_payment set received = 1, action = 'Approved' where (payer = '$payId' and beneficiary = '$benId' and amount = '$amount' and paid = 1 )";
      $confirmRes = $conn->query($confirm)or
      die(mysqli_error($conn));
      if($confirmRes === TRUE){
        $countRem = "SELECT count(*) as rem from cashad_hub_merge where (merge = '$userid' and count = 1 and status = 'Merge') ";
        $countRemRes = $conn->query($countRem)or
        die(mysqli_error($conn));
        $countRemRs = $countRemRes->fetch_assoc();

        if($countRemRs["rem"] > 1){
          //Update Ledger
          $updateLedger = "UPDATE cashad_hub_ledger set withdraw = '$newWithdraw', savings = '$newSavings' where userid = '$payId' ";
          $updateLedgerRes = $conn->query($updateLedger)or
          die(mysqli_error($conn));
          //Update Legeder
          //Update Promotion Time
          $promotion = "INSERT into cashad_hub_promotion (userid,promotion) values ('$payId','$proTime') ";
          $promotionRes = $conn->query($promotion)or
          die(myqsli_error($conn));
          //Update Promotion Time
          //Delete Current merge
          $deleteRequest = "DELETE from cashad_hub_merge where (userid = '$payId' and merge = '$userid' and status = 'Merge')";
          $deleteRequestRes = $conn->query($deleteRequest)or
          die(mysqli_error($conn));
          if($deleteRequestRes === TRUE){
            //Delete Current merge
          ?>
        <script>
          var text = confirm("Confirmation approved successfully");
          if(text === true){
            window.location.href="wallet";
          }
        </script>
        <?php
          }
        }else if($countRemRs["rem"] < 2){
           //Update Payer Ledger
          $updateLedger = "UPDATE cashad_hub_ledger set withdraw = '$newWithdraw', savings = '$newSavings' where userid = '$payId' ";
          $updateLedgerRes = $conn->query($updateLedger)or
          die(mysqli_error($conn));
          //Update Payer Legeder
          //Update Beneficiary Ledger
          $updateBen = "UPDATE cashad_hub_ledger set withdraw = 0 where userid = '$userid' ";
          $updateBenres = $conn->query($updateBen)or
          die(mysqli_error($conn));
          //Update Beneficiary Ledger
          //Update level
          $updateLevel = "UPDATE cashad_hub_users set level = '$newLevel' where userid = '$userid' ";
          $updateLevelRes = $conn->query($updateLevel)or
          die(mysqli_error($conn));
          //Update levele
          //Update Promotion Time
          $promotion = "INSERT into cashad_hub_promotion (userid,promotion) values ('$payId','$proTime') ";
          $promotionRes = $conn->query($promotion)or
          die(myqsli_error($conn));
          //Update Promotion Time
          //Delet Current Merge
          $deleteRequest = "DELETE from cashad_hub_merge where (userid = '$payId' and merge = '$userid' and status = 'Merge')";
          $deleteRequestRes = $conn->query($deleteRequest)or
          die(mysqli_error($conn));
          if($deleteRequestRes === TRUE){
            $deleteRequest = "DELETE from cashad_hub_merge where (userid = '$userid' and merge = 'Yes' and status = 'Merge')";
            $deleteRequestRes = $conn->query($deleteRequest)or
            die(mysqli_error($conn));
            if($deleteRequestRes === TRUE){
      ?>
        <script>
          var text = confirm("Confirmation approved successfully");
          if(text === true){
            window.location.href="wallet";
          }
        </script>
      <?php
            }
          }
        }
      }
    }
    //If beneficiary Recieve payment

   ?>
    <?php
    //Beneficiary don't receive payment
    if(isset($_GET["elaps"])){
      $benId = mysqli_real_escape_string($conn,$_GET["benId"]);
      $payId = mysqli_real_escape_string($conn,$_GET["payId"]);
      $amount = mysqli_real_escape_string($conn,$_GET["amount"]);

      $sqlCount = "SELECT count from cashad_hub_merge where userid = '$benId' and status = 'Merge' and merge = 'Yes' ";
      $sqlCountRes = $conn->query($sqlCount)or
      die(mysqli_error($conn));

      $sqlCountRs = $sqlCountRes->fetch_assoc();
      if($sqlCountRs["count"] < 2){
        $newCount = $sqlCountRs["count"] - 1;

        $sqlUpdateM = "UPDATE cashad_hub_merge set status = 'Pending', merge = 'nill', count = '$newCount' where userid = '$benId' ";
        $sqlUpdateMRes = $conn->query($sqlUpdateM)or
        die(mysqli_error($conn));
        if($sqlUpdateMRes === TRUE){
          $deletePayMerge = "DELETE from cashad_hub_merge where (userid = '$payId' and amount = '$amount' and status = 'Merge' and merge = '$benId' and count = 1) ";
          $deletePayMergeRes = $conn->query($deletePayMerge)or
          die(mysqli_error($conn));

          if($deletePayMergeRes === TRUE){
            $bannedMerg = "UPDATE cashad_hub_users set acstatus = 'Suspended' where userid = '$payId' ";
            $bannedMergRes = $conn->query($bannedMerg)or
            die(mysqli_error($conn));
            if($bannedMergRes === TRUE){
              echo "<script>alert('Confirmation successfully sent');</script>";
              echo "<script>window.location.href='wallet'</script>";
            }
          }
        }
      }else if($sqlCountRs["count"] > 1){
        $newCount = $sqlCountRs["count"] - 1;

        $sqlUpdateM = "UPDATE cashad_hub_merge set count = '$newCount' where userid = '$benId' ";
        $sqlUpdateMRes = $conn->query($sqlUpdateM)or
        die(mysqli_error($conn));
        if($sqlUpdateMRes === TRUE){
          $deletePayMerge = "DELETE from cashad_hub_merge where (userid = '$payId' and amount = '$amount' and status = 'Merge' and merge = '$benId' and count = 1) ";
          $deletePayMergeRes = $conn->query($deletePayMerge)or
          die(mysqli_error($conn));

          if($deletePayMergeRes === TRUE){
            $bannedMerg = "UPDATE cashad_hub_users set acstatus = 'Suspended' where userid = '$payId' ";
            $bannedMergRes = $conn->query($bannedMerg)or
            die(mysqli_error($conn));
            if($bannedMergRes === TRUE){
              echo "<script>alert('Confirmation successfully sent');</script>";
              echo "<script>window.location.href='wallet'</script>";
            }
          }
        }
      }
    }
    //Beneficiary don't receive payment
    ?>
        <?php
            $selectMyMerge = "SELECT * from cashad_hub_merge where (userid = '$userid' and status = 'Picked') ";
            $myMergeRes = $conn->query($selectMyMerge)or
            die(mysqli_error($conn));

            $myMergeRs = $myMergeRes->fetch_assoc();
            $pickerid = $myMergeRs["pickerid"];

            $pickerDetails = "SELECT cashad_hub_users.name as name, cashad_hub_users.phone as phone, cashad_hub_levels.payment as payment from cashad_hub_users inner join cashad_hub_levels on cashad_hub_levels.id = cashad_hub_users.level  where cashad_hub_users.id = '$pickerid' ";
            $pickerDetailsRess = $conn->query($pickerDetails)or
            die(mysqli_error($pickerDetailsRess));
            $pickerDetailsRs = $pickerDetailsRess->fetch_assoc();

            $paymentAmount = $pickerDetailsRs["payment"];

            $date = strtotime($myMergeRs["date_time"]);
            $date = date("F d, Y H:i:s",$date);
            ?>
        <main class="dashboard">

            <div class="quit">
                <button class="quit-btn"><i class="fas fa-hourglass-end"></i>Quit</button>
            </div>
            <?php
                if(isset($_POST["withdraw"])){
                  $amount = mysqli_real_escape_string($conn,$_POST["amount"]);
                  $askMerge = "INSERT into cashad_hub_merge (userid,amount,type,status,level,merge) values ('$userid','$amount','Receive','Pending','$mylevel','nill')";
                  $askMergeRes = $conn->query($askMerge)or
                  die(mysqli_error($askMergeRes));

                  if($askMergeRes === TRUE){
                    set_flash("withdrawall request submited successfuly, kindly wait for the request to be process","success");
                  }else{
                    set_flash("There was error in your withdrawall request, please try again","danger");
                  }
                }

            ?>
            <div class="note">
              <?php echo flash(); ?>
            </div>
            <?php
            //Delete Promotion Time if Elapse
            $checkPro = "SELECT promotion from cashad_hub_promotion where userid = '$userid' ";
            $checkProRes = $conn->query($checkPro)or
            die(mysqli_error($conn));
            $checkProRs = $checkProRes->fetch_assoc();
            $proT = strtotime($checkProRs["promotion"]);
            $now = strtotime(date("F d, Y H:i:s"));
            //Delete Promotion Time
            if($now >= $proT){
              $deletPro = "DELETE from cashad_hub_promotion where userid = '$userid' ";
              $deletProRes = $conn->query($deletPro)or
              die(mysqli_error());
            }
            //Delete Promotion Time
            ?>
            <h2 class="wallet-h2"><i class="fas fa-sack-dollar"></i>My Wallet</h2>
            <div class="card-box">
                <div class="one box">
                    <div class="top-bal">
                        <h3><i class="fas fa-credit-card"></i> Main Balance</h2>
                    </div>

                    <div class="mid-bal">
                       <div class="bal">
                           <p class="naira-icon">&#8358;</p>
                           <p class="naira-bal"><?php echo number_format($walletrs["withdraw"]); ?></p>
                       </div>
                       <div>
                        <i class="fal fa-eye"></i>
                        <i class="far fa-eye-slash"></i>
                       </div>
                    </div>

                    <div class="wallet-box">
                      <?php
                      if($walletrs["withdraw"] == 0){
                      ?>
                      <button onclick="empty();" class="withdraw-btn">Withdraw</button>
                      <?php
                      }else{
                        $checkMerge = "SELECT * from cashad_hub_merge where userid = '$userid' ";
                        $checkMergeRes = $conn->query($checkMerge)or
                        die(mysqli_error($conn));
                        if($checkMergeRes->num_rows > 0){
                      ?>
                        <button onclick="merge();" class="withdraw-btn">Withdraw</button>
                      <?php
                          }else{
                            $checkPro = "SELECT promotion from cashad_hub_promotion where userid = '$userid' ";
                            $checkProRes = $conn->query($checkPro)or
                            die(mysqli_error($conn));
                            if($checkProRes->num_rows > 0){
                              $increase = $checkProRes->fetch_assoc();
                              $increases = strtotime($increase["promotion"]);
                              $increasess = date("F d, Y H:i:s",$increases);
                      ?>
                              <button onclick="promote();" class="withdraw-btn">Withdraw</button>
                              <div class="container">
                                <div class="row text-center">
                                  <div class="col-4"><span id="hours">00</span><br>Hours</div>
                                  <div class="col-4"><span id="minutes">00</span><br>Minutes</div>
                                  <div class="col-4"><span id="seconds">00</span><br>Seconds</div>
                                  <div class="col-12 alert alert-success">You can't withdraw until the time elapse</div>
                                </div>
                              </div>
                              <script>
                              // Set the date we're counting down to
                              var countDownDate = new Date("<?php echo($increasess); ?>").getTime(); //"July 15, 2020 07:42:49"
                              //countDownDate.setHours(countDownDate.getHours() + 5);
                              // Update the count down every 1 second
                              var x = setInterval(function() {

                                  // Get todays date and time
                                  var now = new Date().getTime();
                                  
                                  // Find the distance between now an the count down date
                                  var distance = countDownDate - now;
                                  
                                  // Time calculations for days, hours, minutes and seconds
                                  var days = (Math.floor(distance / (1000 * 60 * 60 * 24))) * (24);
                                  var hours = (Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))) + days;
                                  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                                  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
                                    hours = checkTime(hours);
                                    minutes = checkTime(minutes);
                                      seconds = checkTime(seconds);
                                  // Output the result in an element with id="demo"
                                  document.getElementById("hours").innerHTML = hours;
                                  document.getElementById("minutes").innerHTML = minutes;
                                  document.getElementById("seconds").innerHTML = seconds;
                                  
                                  // If the count down is over, write some text 
                                  if (distance < 0) {
                                      clearInterval(x);
                                      document.getElementById("hours").innerHTML = "11";
                                      document.getElementById("minutes").innerHTML = "11";
                                      document.getElementById("seconds").innerHTML = "11";
                                      //document.getElementById("cantpay").innerHTML = '<i class="far fa-sign-in-alt"></i><a href="javascript:void();" onclick="paidNot();">Paid</a>';
                                      document.getElementById("notes").innerHTML = "<div class='alert alert-info'>Click on the merge button above to check the available memeber for mergin</div>";
                                  }
                              }, 1000);
                              function checkTime(i) {
                                    if (i < 10) {
                                      i = "0" + i;
                                    }
                                    return i;
                                  }
                              </script>
                      <?php
                            }else{
                              $countRef = "SELECT count(*) as totRef from cashad_hub_ref where refuserid = '$userid' and status = 'Activated' ";
                              $countRefRes = $conn->query($countRef)or
                              die(mysqli_error($conn));
                              $countRefRs = $countRefRes->fetch_assoc();
                              $totRef = $countRefRs["totRef"];
                              if($totRef < 4){
                      ?>
                              <button onclick="notRef();" class="withdraw-btn">Withdraw</button>
                      <?php
                              }else{
                      ?>
                              <form method="post" action="">
                                <input type="hidden" name="amount" value="<?php echo($walletrs["withdraw"]) ?>">
                                <button type="submit" name="withdraw" class="withdraw-btn">Withdraw</button>
                              </form>
                      <?php
                              }
                            }
                          }
                        }
                      ?>
                    </div>

                </div>                
                <script>
                  function empty(){
                    alert("Your balance is zero, you can request for any withdraw");
                  }
                  function merge(){
                    alert("You have already request for withdraw, hold for some moment for you to be merge with a member");
                  }
                  function promote(){
                    alert("You can't make any within this perid")
                  }
                  function noteRef(){
                    alert("You can't until your referrals completes to four(4) or above");
                  }
                </script>
                <div class="two box">

                    <div class="top-bal">
                        <h3><i class="fas fa-coins"></i> Savings Balance</h2>
                    </div>

                    <div class="mid-bal">
                       <div class="bal">
                           <p class="naira-icon">&#8358;</p>
                           <p class="naira-bal"><?php echo number_format($walletrs["savings"]); ?></p>
                       </div>
                       <div>
                        <i class="fal fa-eye"></i>
                        <i class="far fa-eye-slash"></i>
                       </div>
                    </div>

                    <div class="wallet-box">
                      <form method="get" action="">
                        <button type="submit" name="" class="withdraw-btn">Withdraw</button>
                      </form>
                    </div>

                </div>

                <div class="three box">

                    <div class="top-bal">
                        <h3><i class="fal fa-cart-plus"></i> Bonus Balance</h2>
                    </div>
                    <?php
                    $countRef = "SELECT count(*) as totRef from cashad_hub_ref where refuserid = '$userid' and status = 'Activated' ";
                    $countRefRes = $conn->query($countRef)or
                    die(mysqli_error($conn));
                    $countRefRs = $countRefRes->fetch_assoc();

                    $totRef = $countRefRs["totRef"];
                    $totRef = $totRef*200;
                    ?>
                    <div class="mid-bal">
                       <div class="bal">
                           <p class="naira-icon">&#8358;</p>
                           <p class="naira-bal"><?php echo number_format($totRef); ?></p>
                       </div>
                       <div>
                        <i class="fal fa-eye"></i>
                        <i class="far fa-eye-slash"></i>
                       </div>
                    </div>

                    <div class="wallet-box">
                      <form method="post" action="affiliate">
                        <button type="submit" name="" class="withdraw-btn">Withdraw</button>
                      </form>
                    </div>
                    

                </div>

              
            </div>
            <?php
            /*
              if(isset($_POST["confirm"])){
                $addedTime = "";
                if($paymentAmount == 1000){
                  $addedTime = strtotime("+24 Hours");
                }else if($paymentAmount == 2000){
                  $addedTime = strtotime("+2 Days");
                }else if($paymentAmount == 4000){
                  $addedTime = strtotime("+4 Days");
                }else if($paymentAmount == 6000){
                  $addedTime = strtotime("+5 Days");
                }else if($paymentAmount == 10000){
                  $addedTime = strtotime("+7 Days");
                }else if($paymentAmount == 16000){
                  $addedTime = strtotime("+8 Days");
                }else if($paymentAmount == 24000){
                  $addedTime = strtotime("+10 Days");
                }

                $statusDate = date("F d, Y H:i:s",$addedTime);
                $updatePayment = "UPDATE cashad_hub_payment set status = 'Approved', status_date_updated = '$statusDate' where (receiver_id = '$myId' and status = 'Pending' and amount = '$paymentAmount' )";
                $updatePaymentRes = $conn->query($updatePayment)or
                die(mysqli_error($conn));

                if($updatePaymentRes === TRUE){
                  set_flash("Payment confirmed","success");
                  echo "<script>alert('Payment confirmed');</script>";
                  $unmergeSender = "UPDATE cashad_hub_users set merge = '0' where id = '$pickerid' ";
                  $unmergeSenderRes = $conn->query($unmergeSender)or
                  die(mysqli_error($conn));

                  //Delete Merge Details
                  $deleteMerge = "DELETE from cashad_hub_merge where (userid = '$userid' and recieverid = '$myId' and status = 'Picked') ";
                  $deleteMergeRes = $conn->query($deleteMerge)or
                  die(mysqli_error($conn));

                  $fecthBalance = "SELECT * from cashad_hub_ledger where user_id = '$userid' ";
                  $fecthBalanceRes = $conn->query($fecthBalance)or
                  die(mysqli_error());

                  if($fecthBalanceRes->num_rows > 0){
                    $fecthBalanceRs = $fecthBalanceRes->fetch_assoc();
                    $myBalance = $fecthBalanceRs["withdraw"];

                    $updateBalance = "UPDATE cashad_hub_ledger set withdraw = '0' where user_id = '$userid' ";
                    $updateBalanceRes = $conn->query($updateBalance)or
                    die(mysqli_error($conn));
                  }


                }else{
                  set_flash("Payment not confirmed","danger");
                }
              }
            */
            ?>
            <!-- note section -->            
            <div class="note">
                <p><span>Note:</span>
                    Kindly contact the merge member to speed up your withdraw.
                    Click the confirm payment button to confirm that you have recieved 
                    payment from the merged details delow, failure to do so will result 
                    to blocking of your account...
            </div>
            <div class="recieve">
              <span class="col-sm-12"><?php echo flash(); ?></span>
            </div>
            <?php
              $sqls = "SELECT cashad_hub_merge.amount as amount, cashad_hub_merge.userid as payId, cashad_hub_merge.level as level, cashad_hub_merge.date_merge as date_merge, cashad_hub_users.name as name, cashad_hub_users.phone from cashad_hub_merge inner join cashad_hub_users on cashad_hub_merge.userid = cashad_hub_users.userid where (cashad_hub_merge.merge = '$userid' and cashad_hub_merge.status = 'Merge') order by date_merge asc ";
                      $results = $conn->query($sqls)or
                      die(mysqli_error($conn));

                      if($results->num_rows > 0){
                        $sn = "";
                        $hr = "";
                        $mi = "";
                        $se = "";
                        $da = "";
                        $co = "";
                        $dis= "";
                        $x = "";
                        $ns = "";
                        $vs = "";
                        $cl = "";
                        $py = "";
                        $cn = "";
                        $ac = "";
                        $elp = "";
                        $don = "";
                        while($res = $results->fetch_assoc()){
                          $buttons = "buttons".++$sn;
                          $day = "days".++$da;
                          $hour = "hours".++$hr;
                          $min = "minutes".++$mi;
                          $sec = "seconds".++$se;
                          $distance = "distance".++$dis;
                          $countDownDate = "countDownDate".++$co;
                          $x = "x".++$x;
                          $elapse = "elapse".++$elp;
                          $don = "don".++$don;
                          $m_date = strtotime($res["date_merge"]);
                          $merge_date = date("F d, Y H:i:s",$m_date);
                          
                          $payId = $res["payId"];
            ?>
            <div class="payment-info">
                <div class="pay-box">
                    <p>You are to recieve &#8358;<span id="price"><?php echo $res["amount"]; ?></span> from the merge-details below</p>
                </div>
            </div>

            <!-- merge customer's details -->
            <div class="merge-details">
                <h2>Merge Details</h2>
                <div class="merge-box">
                    <div>Name:<span id="name"><?php echo $res["name"]; ?></span></div>
                    <div>Phone no:<span id="tel"><?php echo $res["phone"]; ?></span></div>
                </div>
            </div>
            <?php
                      $checkPay = "SELECT * from cashad_hub_payment where payer = '$payId' and beneficiary = '$userid' and paid = 1 ";
                      $checkPayRes = $conn->query($checkPay)or
                      die(mysqli_error($conn));
                      if($checkPayRes->num_rows > 0){
                        while($files = $checkPayRes->fetch_assoc()){
                          $pays = "pays".++$ns;
                          $viewPay = "viewPay".++$vs;
                          $close = "closePay".++$cl;
                          $py = "yes".++$py;
                          $ac= "action".++$ac;
                          $payIds = "payId".++$cn;
                    ?> 
                    <div class="note">
                      <div class="alert alert-success">
                        <p>Payment has been made please, kindly confirm the payment</p>
                        <form method="post" action="">
                          <input type="hidden" name="payId" value="<?php echo($payId); ?>">
                          <input type="hidden" name="benId" value="<?php echo($userid); ?>">
                          <input type="hidden" name="amount" value="<?php echo($res["amount"]); ?>">
                          <input type="hidden" name="level" value="<?php echo($res["level"]); ?>">
                          <button type="submit" name="received" class="btn btn-success">Received <i class="fa fa-check"></i></button>
                          <!--<a class='btn btn-success' href="dashboard?payId=<?php echo($payId); ?>&benId=<?php echo($userid); ?>&amount=<?php echo($res["amount"]) ?>"></a>-->
                          <a class="btn btn-info" href="javascript:void();" onclick="<?php echo($viewPay); ?>();">View <i class="fa fa-eye"></i></a>
                        </form>
                      </div>
                      <div class="pays" id="<?php echo($pays); ?>">
                        <span class="close-btn" onclick="<?php echo($close); ?>();">&times;</span>
                        <div class="container" style="margin: auto;">
                          <div class="row">
                            <div class="col-md-4 img">
                              <div class="img">
                                <img src="<?php echo "../payment/".$files["file"]; ?>" >
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                      <script>
                        function <?php echo($viewPay); ?>(){
                          document.getElementById("<?php echo($pays); ?>").style.display = 'block';
                        }
                        function <?php echo($close); ?>(){
                          document.getElementById("<?php echo($pays); ?>").style.display = 'none';
                        }
                      </script>
                    <?php
                        }
                      }else{
                    ?>
                    <div class="text-center" id="<?php echo($buttons) ?>" style="margin-bottom: 10px;"></div>
                      <h3 class="count-name">Count down</h3>
                      <!-- count down section -->
                      <div class="count-down">
                          <div class="box">
                            <div class="box-con">
                              <div class="t-box" id="<?php echo($hour) ?>"></div>
                                <p class="colon">:</p>
                              </div>
                              <p class="time">hours</p>
                          </div>
                          <div class="box">
                            <div class="box-con">
                              <div class="t-box" id="<?php echo($min) ?>"></div>
                                <p class="colon">:</p>
                              </div>
                            <p class="time">minute</p>
                          </div>
                          <div class="box">
                            <div class="box-con">
                              <div class="t-box" id="<?php echo($sec) ?>"></div>
                            </div>
                            <p class="time">seconds</p>
                          </div>
                      </div>
                  <?php
                    }
                  ?>
                  <script>
                    // Set the date we're counting down to
                    var <?php echo ($countDownDate); ?> = new Date("<?php echo($merge_date); ?>").getTime(); //"July 15, 2020 07:42:49"
                    //countDownDate.setHours(countDownDate.getHours() + 5);
                    // Update the count down every 1 second
                    var <?php echo ($x); ?> = setInterval(function() {

                        // Get todays date and time
                        var now = new Date().getTime();
                        
                        // Find the distance between now an the count down date
                        var <?php echo ($distance); ?> = <?php echo ($countDownDate); ?> - now;
                        
                        // Time calculations for days, hours, minutes and seconds
                        var <?php echo ($day); ?> = (Math.floor((<?php echo ($distance); ?>) / (1000 * 60 * 60 * 24))) * (24);
                        var <?php echo($hour) ?> = (Math.floor(((<?php echo ($distance); ?>) % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))) + <?php echo ($day); ?>;
                        var <?php echo($min) ?> = Math.floor(((<?php echo ($distance); ?>) % (1000 * 60 * 60)) / (1000 * 60));
                        var <?php echo($sec) ?> = Math.floor(((<?php echo ($distance); ?>) % (1000 * 60)) / 1000);
                          <?php echo($hour) ?> = checkTime(<?php echo($hour) ?>);
                          <?php echo($min) ?> = checkTime(<?php echo($min) ?>);
                            <?php echo($sec) ?> = checkTime(<?php echo($sec) ?>);
                        // Output the result in an element with id="demo"
                        document.getElementById("<?php echo($hour) ?>").innerHTML = <?php echo($hour) ?>;
                        document.getElementById("<?php echo($min) ?>").innerHTML = <?php echo($min) ?>;
                        document.getElementById("<?php echo($sec) ?>").innerHTML = <?php echo($sec) ?>;
                        
                        // If the count down is over, write some text 
                        if (<?php echo ($distance); ?> < 0) {
                            clearInterval(<?php echo ($x); ?>);
                            document.getElementById("<?php echo($hour) ?>").innerHTML = "00";
                            document.getElementById("<?php echo($min) ?>").innerHTML = "00";
                            document.getElementById("<?php echo($sec) ?>").innerHTML = "00";
                            document.getElementById("<?php echo($buttons) ?>").innerHTML = '<a class="btn btn-danger" href="wallet?elaps=yes&benId=<?php echo($userid); ?>&payId=<?php echo($payId); ?>&amount=<?php echo($res["amount"]) ?>"><i class="fa fa-times"></i>I Don\'t Received</a>';
                        }
                    }, 1000);
                    function checkTime(i) {
                          if (i < 10) {
                            i = "0" + i;
                          }
                          return i;
                        }
                    </script>
            <?php
              }
            }
            ?>
            


        </main>

        <footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="#"><img src="img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="#"><img src="img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="#"><img src="img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:tee.jhay1@gmail.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; <?php echo date("Y"); ?> <span>CashadHub</span></p>
            </div>
        </footer>

    </div>






  <script src="javascript/wallet.js"></script>
  <script src="javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="../assets/theme/js/script.js"></script>
 


  <input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience. Read our <a href='privacy.html'>cookie policy</a>.">
  <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a>
  </div>
   <input name="animation" type="hidden">




<script>
    if (window.history.replaceState) {
      window.history.replaceState(null, null, window.location.href);
    }
</script>
  </body>
</html>