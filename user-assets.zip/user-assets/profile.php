<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->


<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  
  
  <title>Profile</title>
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  <link rel="preload" as="style" href="../assets/mobirise/css/mbr-additional.css">
  <link rel="stylesheet" href="../assets/mobirise/css/mbr-additional.css" type="text/css">
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lemonada:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>
  <link rel="stylesheet" href="css/user.css">
  <link rel="stylesheet" href="css/profile.css">


</head>
<body>
    <!--[if lt IE 7]>
        <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>

        <!-- nav links -->
            <?php require 'inc/nav.php' ?>
        </header>

        <main class="dashboard">
            <div id="profile-box">
                <h1>Personal info</h1>
                <div>
                    <h2>Full Name</h2>
                    <p id="full-name"><?php echo $rs["name"]; ?></p>
                    <h2>Username</h2>
                    <p id="username"><?php echo $rs["username"]; ?></p>
                    <h2>Email</h2>
                    <p id="email"><?php echo $rs["email"]; ?></p>
                    <h2>Phone</h2>
                    <p id="phone"><?php echo $rs["phone"]; ?></p>
                    <h2>Gender</h2>
                    <p id="gender"><?php echo $rs["gender"]; ?></p>
                    <h2>Date of Birth</h2>
                    <p id="dob"><?php echo date("F d, Y",strtotime($rs["dob"])); ?></p>
                    <h2>State</h2>
                    <p id="state"><?php echo $rs["state"]; ?></p>
                    <h2>Gender</h2>
                    <p><?php echo $rs["gender"]; ?></p>
                </div>
                <h1>Bank Details</h1>
                <div>
                    <h2>Bank Account Name</h2>
                    <p id="b-acc-name"><?php echo $bkrs["account_name"]; ?></p>
                    <h2>Bank Account Number</h2>
                    <p id="b-acc-no"><?php echo $bkrs["account_num"]; ?></p>
                    <h2>Bank Name</h2>
                    <p id="bank-name"><?php echo $bkrs["bank_name"]; ?></p>                
                </div>
                <?php
                  if(isset($_POST["update"])){
                    $oldpassword = $_POST["oldpassword"];
                    $newpassword = $_POST["newpassword"];
                    $cnewpassword = $_POST["cnewpassword"];

                    $username = $rs["username"];

                    if($oldpassword == "" || $newpassword == "" || $cnewpassword == ""){
                      echo "<script>alert('All fileds must be fill');</script>";
                      set_flash("All fields must be fill", "danger");
                    }else{
                      $oldpassword = sha1($_POST["oldpassword"]);
                      $checkpassword = "SELECT * from cashad_hub_users where username = '$username' and password = '$oldpassword' ";
                      $passresult = $conn->query($checkpassword)or
                      die(mysqli_error($conn));

                      if($passresult->num_rows < 1 ){
                        echo "<script>alert('Invalid old password');</script>";
                        set_flash("Invalid old password", "danger");
                      }else{
                        if($newpassword !== $cnewpassword){
                          echo "<script>alert('New password do not match with confirm password');</script>";
                          set_flash("New password do not match with confirm password", "danger");
                        }else{
                          $newpassword = sha1($_POST["newpassword"]);
                          $updatepassword = "UPDATE cashad_hub_users set password = '$newpassword' where username = '$username' ";
                          $updatresult = $conn->query($updatepassword)or
                          die(mysqli_error($conn));

                          if($updatresult === TRUE){
                            echo "<script>alert('Password updated successfully');</script>";
                            set_flash("Password updated successfully", "danger");
                          }
                        }
                      }
                    }
                  }

                ?>
                <h1>Change Password</h1>
                <div>
                    <?php flash(); ?>
                    <form action="profile.php" method="post">
                        <h2>Old Password</h2>
                        <input type="password" name="oldpassword" id="old-pass" placeholder="*************" >
                        <h2>New Password</h2>
                        <input type="password" name="newpassword" id="new-pass" placeholder="*************" >
                        <h2>Retype New Password</h2>
                        <input type="password" name="cnewpassword" id="retype-pass" placeholder="*************" >
                        <input type="submit" name="update" value="UPDATE" id="update">
                    </form>               
                </div>         
                
            </div>
        </main>

        <footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="#"><img src="img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="#"><img src="img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="#"><img src="img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:tee.jhay1@gmail.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; 2020 <span>CashadHub</span></p>
            </div>
        </footer>

    </div>




  <script src="javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="../assets/theme/js/script.js"></script>
  

  <input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience. Read our <a href='privacy.html'>cookie policy</a>.">
  <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a>
  </div>
   <input name="animation" type="hidden">  

  </body>
</html>