<?php
require '../config/config.php';
require 'function2.php';
?>
<!DOCTYPE html>
<html class="no-js"> <!--<![endif]-->


<html  >
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.12.3, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="/assets/images/cashfo-239x274.png" type="image/x-icon">
  <meta name="description" content="">
  <title>Affiliate</title>
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="../assets/tether/tether.min.css">
  <link rel="stylesheet" href="../assets/dropdown/css/style.css">
  <link rel="stylesheet" href="../assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="../assets/theme/css/style.css">
  <link rel="preload" as="style" href="../assets/mobirise/css/mbr-additional.css">
  <link href="https://fonts.googleapis.com/css2?family=Lobster&family=Pacifico&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Lemonada:wght@400;500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,500;0,600;1,600;1,700&family=Rubik:wght@400;500;700&display=swap" rel="stylesheet">
  <script src="../font.js"></script>
  <link rel="stylesheet" href="css/user.css">
  <link rel="stylesheet" href="css/profile.css">
  <link rel="stylesheet" href="css/affiliate.css">
   <link rel="stylesheet" href="../lib/font-awesome/font-awesome.min.css"> 
 <link rel="stylesheet" href="../lib/bootstrap/css/bootstrap.min.css">

</head>
<body>
  <?php
    if(isset($_POST["withdraw"])){
      $bonuses = mysqli_real_escape_string($conn,$_POST["bonus"]);
      $withdraw = "INSERT into cashad_hub_bonus (userid,amount,paid) values ('$userid','$bonuses','Pending') ";
      $withdrawRes = $conn->query($withdraw)or
      die(mysqli_error($conn));
      if($withdrawRes === TRUE){
        $deleteRef = "DELETE from cashad_hub_ref where refuserid = '$userid' ";
        $deleteRefRes = $conn->query($deleteRef)or
        die(mysqlie_error($conn));
        if($deleteRefRes === TRUE){
          set_flash("Withdrawal successfully submitted","success");
        }else{
          set_flash("There was error in submiting withdrawal","danger");
        }
      }
    }
    ?>
         <!--[if lt IE 7]>
            <p class="browsehappy">You are using an <strong>outdated</strong> browser. Please <a href="#">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
    <div class="root">
        <!-- header and nav-bar-->
        <header>

            <div class="head">
                <div class="nav-bar">
                   <div class="hamburger-logo">
                       <div class="hamburger">
                           <div class="line"></div>
                           <div class="line"></div>
                           <div class="line"></div>
                       </div>
                       <div class="brand-name">
                        Cashad<span>Hub</span>
                       </div>
                   </div>
                   <div class="notify">
                        <a href="#"><i class="fas fa-bell" id="bell"></i><sup id="sup">99+</sup></a>
                   </div>
                </div>
            </div>

        <!-- nav links -->
            <?php require 'inc/nav.php' ?>
        </header>
        <?php
        $countRef = "SELECT count(*) as totRef from cashad_hub_ref where refuserid = '$userid' and status = 'Activated' ";
        $countRefRes = $conn->query($countRef)or
        die(mysqli_error($conn));
        $countRefRs = $countRefRes->fetch_assoc();

        $totRef = $countRefRs["totRef"];
        $totRef = $totRef*200;
        ?>
        <main class="dashboard">
          <div class="note">
            <div class="alert alert-info">
              Total Refeeral Bonus &#8358;<?php echo $totRef; ?>
            </div>
            <div>
              <form action="" method="post">
                <div class="form-group" style="display: flex;">
                  <input class="form-control" disabled="" type="hidden" name="bonus" value="<?php echo($totRef); ?>">
                  <div class="form-control" style="height: 38px; padding: 6px; padding-left: 10px; font-size: 20px;">&#8358;<?php echo($totRef); ?></div>
                  <?php
                  if($totRef < 2000){
                  ?>
                  <button type="button" onclick="cantWithdraw();" class="btn btn-danger" style="border-bottom-left-radius: 0; border-top-left-radius: 0;">Withdraw</button>
                  <?php
                  }else{
                  ?>
                  <button type="submit" name="withdraw" class="btn btn-success" style="border-bottom-left-radius: 0; border-top-left-radius: 0;">Withdraw</button>
                  <?php
                  }
                  ?>
                </div>
              </form>
            </div>
            <script>
              function cantWithdraw(){
                alert("You can't withdraw until your bonus mount up to 2000");
              }
            </script>
          </div>
            <div class="ref-link">
                <p id="link">https://www.cashadhub.com/registerref?ref=<?php echo $userid; ?></p>
                <button class="copy-btn"><i class="fa fa-copy"></i></button>
            </div>
            <h1 class="downlines">My Downlines</h1>
           <div class="note">
              <div class="col-12 table-responsive">
                <table class="table table-striped">
                  <tr>
                    <th>SN</th>
                    <th>USER-NAME</th>
                    <th>USER-ID</th>
                    <th>STATUS</th>
                  </tr>
                   <?php
                   $referral = "SELECT cashad_hub_users.userid as userid, cashad_hub_users.username as username, cashad_hub_users.acstatus as acstatus, cashad_hub_ref.inviteduserid as invited from cashad_hub_users inner join cashad_hub_ref on  cashad_hub_users.userid = cashad_hub_ref.inviteduserid where cashad_hub_ref.refuserid = '$userid' order by cashad_hub_ref.id DESC ";
                            $referralRes = $conn->query($referral)or
                            die(mysqli_error($conn));
                            $sn = 0;
                            if($referralRes->num_rows > 0){
                              $sn = "";
                              while($referralRs = $referralRes->fetch_assoc()){
                                $acstatus = $referralRs["acstatus"];
                    ?>
                    <tr>
                      <td><?php echo ++$sn; ?></td>
                      <td><?php echo $referralRs["username"]; ?></td>
                      <td><?php echo $referralRs["invited"]; ?></td>
                      <td><span class="<?php if($acstatus == "Not Activated"){echo("btn btn-danger btn-sm");}else if($acstatus == "Activated"){echo("btn btn-success btn-sm");} ?>"><?php echo $referralRs["acstatus"]; ?></span></td>
                    </tr>
                     <?php
                   }
                 }
                   ?>
                 </table>
               </div>
           </div>
           <div class="note">
                        <div class="alert alert-info">
                          Referral Withdrawal
                        </div>
                      <table class="table">
                      <thead>
                        <tr>
                          <th>S/N</th>
                          <th>User Id</th>
                          <th>Amount</th>
                          <th>Status</th>
                          <th>Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          $bonus = "SELECT * from cashad_hub_bonus where userid = '$userid' ";
                          $bonusRes = $conn->query($bonus)or
                          die(mysqli_error($conn));
                          if($bonusRes->num_rows > 0){
                            $sn = "";
                            while($bonusRs = $bonusRes->fetch_assoc()){
                      ?>
                      <tr>
                        <td><?php echo ++$sn; ?></td>
                        <td><?php echo $bonusRs["userid"]; ?></td>
                        <td>&#8358;<?php echo number_format($bonusRs["amount"]); ?></td>
                        <td><span <?php if($bonusRs["paid"] == "Pending"){echo "class='btn btn-warning'";}elseif($bonusRs["paid"] == "Paid"){echo "class='btn btn-success'";} ?>><?php echo $bonusRs["paid"]; ?></span></td>
                        <td><?php echo $bonusRs["date"]; ?></td>
                      </tr>
                      <?php
                            }
                          }
                        ?>
                      </tbody>
                      </table>
                      </div>
        </main>

        <footer class="footer">
            <div class="media">
                
                <div class="whatsapp">
                    <div class="wa1">
                        <a href="#"><img src="img/whatsapp2.png" alt=""></a>
                        <p>WhatsApp</p>
                    </div>
                    <div class="wa2">
                        <a href="#"><img src="img/twitter.png" alt=""></a>
                        <p>Twitter</p>
                    </div>
                    <div class="wa3">
                        <a href="#"><img src="img/instagram.png" alt=""></a>
                        <p>Instagram</p>
                    </div>
                </div>

                <div class="tel-fb">
                    <div class="telegram">
                        <a href="#"><img src="img/paper-plane.svg" alt=""></a>
                        <p>Telegram</p>
                    </div>
                    <div class="fb">
                        <a href="#"><img src="img/fb.png" alt=""></a>
                        <p>Facebook</p>
                    </div>
                </div>

                <div class="email">
                    <p>
                        Support Email: <a href="mailto:tee.jhay1@gmail.com">support@cashadHub.com</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                <p>Copyright &copy; 2020 <span>CashadHub</span></p>
            </div>
        </footer>

    </div>



    
  <script src="javascript/affiliate.js"></script>
  <script src="javascript/user.js"></script>
  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/popper/popper.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/tether/tether.min.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-core.js"></script>
  <script src="../assets/web/assets/cookies-alert-plugin/cookies-alert-script.js"></script>
  <script src="../assets/dropdown/js/nav-dropdown.js"></script>
  <script src="../assets/dropdown/js/navbar-dropdown.js"></script>
  <script src="../assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="../assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="../assets/smoothscroll/smooth-scroll.js"></script>
  <script src="../assets/theme/js/script.js"></script>
  

  <input name="cookieData" type="hidden" data-cookie-customDialogSelector='null' data-cookie-colorText='#424a4d' data-cookie-colorBg='rgba(234, 239, 241, 0.99)' data-cookie-textButton='Agree' data-cookie-colorButton='' data-cookie-colorLink='#424a4d' data-cookie-underlineLink='true' data-cookie-text="We use cookies to give you the best experience. Read our <a href='privacy.html'>cookie policy</a>.">
  <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a>
  </div>
   <input name="animation" type="hidden">  
  </body>
</html>